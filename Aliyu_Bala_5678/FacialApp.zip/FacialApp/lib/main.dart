import 'pages/dashboards/about.dart';
import 'pages/dashboards/overview.dart';
import 'pages/dashboards/capture.dart';
import 'pages/dashboards/verification.dart';
import 'pages/dashboards/Userguide.dart';
import 'pages/dashboards/requirement.dart';
import 'pages/dashboards/introduction.dart';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';


import 'package:periodic_alarm/periodic_alarm.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final storage = const FlutterSecureStorage();
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    checkForSavedCredentials();
  }

  void checkForSavedCredentials() async {
    String? username = await storage.read(key: 'username');
    if (username != null) {
      usernameController.text = username;
    }
  }

  void login() async {
    String username = usernameController.text;
    String password = passwordController.text;

    // Check if user data exists in local storage
    String? storedUsername = await storage.read(key: 'username');
    String? storedPassword = await storage.read(key: 'password');

    if (username == storedUsername && password == storedPassword) {
      String? name = await storage.read(key: 'name') ?? '';
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => DashboardPage(username: name),
        ),
      );
    } else {
      // Handle login failure
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Login Failed'),
          content: Text('Invalid username or password.'),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white ,
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset('assets/images/face2.jpg',height: MediaQuery.of(context).size.height/3,),
                Text(
                  'Welcome Back ',
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: usernameController,
                    decoration: InputDecoration(
                      labelText: 'Username',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.person),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: passwordController,
                    decoration: InputDecoration(
                      labelText: 'Password',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.lock),
                    ),
                    obscureText: true,
                  ),
                ),
                ElevatedButton(
                  onPressed: login,
                  child: Container(
                    width: MediaQuery.of(context).size.width - 200,
                    child: Center(child: Text('Login')),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => SignupPage()));
                  },
                  child: Text('Sign Up'),
                ),
                IconButton(
                    onPressed: null,
                    icon: Icon(
                      Icons.fingerprint_rounded,
                      size: 50.0,
                    )),
             
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SignupPage extends StatefulWidget {
  @override
  _SignupPageState createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final storage = FlutterSecureStorage();
  TextEditingController nameController = TextEditingController();
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController comfirmpasswordController = TextEditingController();
  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  bool passwordMismatch = false;
  void signup() async {
    String name = nameController.text;
    String username = usernameController.text;
    String password = passwordController.text;
    String comfirmpassword = comfirmpasswordController.text;

    if (password != comfirmpassword) {
      setState(() {
        passwordMismatch = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('The password is not the same'),
        ),
      );
    } else {
      setState(() {
        passwordMismatch = false;
      });
      // Store user data in local storage
      await storage.write(key: 'name', value: name);
      await storage.write(key: 'username', value: username);
      await storage.write(key: 'password', value: password);

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => DashboardPage(username: name),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Sign Up Page'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Create an Account',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Form(
              key: formKey,
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: nameController,
                      decoration: InputDecoration(
                        labelText: 'Full Name',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.perm_contact_cal_outlined),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: usernameController,
                      decoration: InputDecoration(
                          labelText: 'Username',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.person)),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: passwordController,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.lock),
                      ),
                      obscureText: true,
                    ),
                  ),
                  // Other form fields here...
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      controller: comfirmpasswordController,
                      decoration: InputDecoration(
                        iconColor: passwordMismatch ? Colors.red : Colors.grey,
                        fillColor: passwordMismatch ? Colors.red : Colors.grey,
                        focusColor: passwordMismatch ? Colors.red : Colors.grey,
                        focusedErrorBorder: UnderlineInputBorder(
                          borderSide: BorderSide(
                            color: passwordMismatch ? Colors.red : Colors.grey,
                          ),
                        ),
                        labelText: 'Confirm Password',
                        border: OutlineInputBorder(
                          borderSide: BorderSide(
                            color: passwordMismatch ? Colors.red : Colors.grey,
                          ),
                        ),
                        prefixIcon: Icon(Icons.lock),
                      ),
                      obscureText: true,
                    ),
                  ),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: () {
                if (formKey.currentState!.validate()) {
                  signup();
                }
              },
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}

class DashboardPage extends StatefulWidget {
  final String username;

  DashboardPage({super.key, required this.username});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  @override
  void initState() {
    super.initState();
    PeriodicAlarm.init();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: SafeArea(
          child: SingleChildScrollView(
            child: Container(
              child: Column(
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width - 2,
                    child: Card(
                      child: DrawerHeader(
                        child: Column(
                          children: [
                            SizedBox(
                              height: 90,
                              width: MediaQuery.of(context).size.width,
                              child: CircleAvatar(
                                child: Icon(
                                  Icons.person,
                                  size: 80,
                                ),
                              ),
                            ),
                            Text(
                              '${widget.username}',
                              style: TextStyle(fontSize: 20),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Capture()),
                        );
                      },
                      // title:
                      subtitle: Text(
                        'Capture',
                      ),
                      trailing: Icon(
                        Icons.healing,
                        color: Colors.blue,
                      ),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => verification()),
                        );
                      },
                      // title:
                      subtitle: Text(
                        'Verification',
                      ),
                      trailing: Icon(
                        Icons.nights_stay,
                        color: Colors.blue,
                      ),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Introduction()),
                        );
                      },
                      // title:
                      subtitle: Text(
                        'System Architecture',
                      ),
                      trailing: Icon(
                        Icons.accessibility,
                        color: Colors.blue,
                      ),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => overview()),
                        );
                      },
                      // title:
                      subtitle: Text(
                        'Project overview',
                      ),
                      trailing: Icon(
                        Icons.ac_unit_rounded,
                        color: Colors.blue,
                      ),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Requirement()),
                        );
                      },
                      // title:
                      subtitle: Text(
                        'security',
                      ),
                      trailing: Icon(
                        Icons.security,
                        color: Colors.blue,
                      ),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      // title:
                      subtitle: Text(
                        'Requiremt',
                      ),
                      trailing: Icon(
                        Icons.play_circle_outline_rounded,
                        color: Colors.blue,
                      ),
                    ),
                  ),

                  Card(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => About()),
                        );
                      },
                      // title:
                      subtitle: Text(
                        'Project Write up',
                      ),
                      trailing: Icon(
                        Icons.book,
                        color: Colors.blue,
                      ),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => About()),
                        );
                      },
                      // title:
                      subtitle: Text(
                        'About',
                      ),
                      trailing: Icon(
                        Icons.info_outline,
                        color: Colors.blue,
                      ),
                    ),
                  ),
                  Card(
                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => LoginPage()),
                        );
                      },
                      // title:
                      subtitle: Text(
                        'Logout',
                      ),
                      trailing: Icon(
                        Icons.power_settings_new,
                        color: Colors.red,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      appBar: AppBar(
        title: const Text('Facial Recognition'),
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => LoginPage(),
                ),
              );
            },
            icon: Icon(Icons.power_settings_new),
            color: Colors.amber,
          )
        ],
      ),
      body: Column(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(20),
            // child:Text("Welcome Back}" ),
            child: Text(
              'Welcome. Back!',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            flex: 1,
            child: GridView.count(
              crossAxisCount: 2,
              children: <Widget>[
                DashboardCard(
                  title: 'Capture',
                  icon: Icons.person,
                  nextPage: Capture(),
                ),
                DashboardCard(
                  title: 'Verification',
                  icon: Icons.security,
                  nextPage: verification(),
                ),
                DashboardCard(
                  title: 'Introduction',
                  icon: Icons.accessibility,
                  nextPage: Introduction(),
                ),
                DashboardCard(
                  title: 'Project Overview',
                  icon: Icons.ac_unit_rounded,
                  nextPage: overview(),
                ),
                DashboardCard(
                  title: 'Requirements',
                  icon: Icons.settings,
                  nextPage: Requirement(),
                ),
                DashboardCard(
                  title: 'User Guide',
                  icon: Icons.lightbulb,
                  nextPage: MyplayList(),
                ),
                // DashboardCard(
                //   title: 'Alarm',
                //   icon: Icons.alarm,
                //   nextPage: Alarm(),
                // ),
              ],
            ),
          ),
        ],
      ),

    );
  }
}

class DashboardCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget nextPage;
  DashboardCard(
      {required this.title, required this.icon, required this.nextPage});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Navigate to the specified page
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => nextPage),
        );
      },
      child: Card(
        elevation: 5,
        margin: const EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(
              icon,
              size: 64,
              color: Theme.of(context).primaryColor,
            ),
            Text(
              title,
              style: const TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
