import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class Introduction extends StatefulWidget {
  @override
  State<Introduction> createState() => _IntroductionState();
}

class _IntroductionState extends State<Introduction> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    String link = "assets/videos/ins1.mp4";
    super.initState();
    _controller = VideoPlayerController.asset(link,
        videoPlayerOptions: VideoPlayerOptions(allowBackgroundPlayback: true))
      ..initialize().then((_) {
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        setState(() {
          _controller.play();
        });
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Insomnia'),
      ),
      body: ListView(
        children: <Widget>[
          // Title Section
          Container(
            padding: EdgeInsets.all(20),
            child: Text(
              'Sysmtoms',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),

          // Image Section
          Card(
            margin: EdgeInsets.all(10),
            child: Image.asset('assets/images/symp.png'),
          ),
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              "List of some Common Symptoms. ",
              style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),
            ),
          ),
          // Text Section
          Divider(
            color: Theme.of(context).primaryColor,
            thickness: 2,

          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('1'),
                ),
              ),
              title: Text("Difficulty falling asleep at night"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('2'),
                ),
              ),
              title: Text("Waking up during the night"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('3'),
                ),
              ),
              title: Text("Waking up too early"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('4'),
                ),
              ),
              title: Text("Not feeling well-rested after a night's sleep"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('5'),
                ),
              ),
              title: Text("Daytime tiredness or sleepiness"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('6'),
                ),
              ),
              title: Text("Irritability, depression or anxiety"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('7'),
                ),
              ),
              title: Text(
                  "Difficulty paying attention, focusing on tasks or remembering "),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('8'),
                ),
              ),
              title: Text("Increased errors or accidents"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('9'),
                ),
              ),
              title: Text("Ongoing worries about sleep"),
            ),
          ),
          // Video Section


        ],
      ),
    );
  }
}
