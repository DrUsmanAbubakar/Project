import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class Requirement extends StatefulWidget {
  @override
  State<Requirement> createState() => _RequirementState();
}

class _RequirementState extends State<Requirement> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    String link = "assets/videos/ins1.mp4";
    super.initState();
    _controller = VideoPlayerController.asset(link,
        videoPlayerOptions: VideoPlayerOptions(allowBackgroundPlayback: true))
      ..initialize().then((_) {
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        setState(() {
          _controller.play();
        });
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Insomnia'),
        centerTitle: true,
      ),
      body: ListView(
        children: <Widget>[
          // Title Section
          Container(
            padding: EdgeInsets.all(20),
            child: Text(
              'Prevention',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),

          // Image Section
          Card(
            margin: EdgeInsets.all(10),
            child: Image.asset('assets/images/prevent.png'),
          ),
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              "Prevention of Insomnia",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            ),
          ),
          // Text Section
          Divider(
            color: Theme.of(context).primaryColor,
            thickness: 2,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              child: Text(
                  "Stress and anxiety are potent sleep slayers. If the stuff you’re "
                  "doing before bed (or while you’re in bed) causes you to feel anxious — whether you’re watching the news, sending work emails, or scrolling your social media feeds — you’ll want "
                  "to avoid those activities before they start messing with your slumber"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('1'),
                ),
              ),
              title: Text(
                  "Get up and go to sleep at the same time every day, even on weekends"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('2'),
                ),
              ),
              title: Text(
                  "Get regular physical activity, which includes walking and other low-impact exercises (but avoid vigorous exercise too close to bedtime, which tends to wake up and energize your body)"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('3'),
                ),
              ),
              title: Text("Avoid taking long or frequent naps"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('4'),
                ),
              ),
              title: Text("Limit your caffeine and alcohol intake"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('5'),
                ),
              ),
              title: Text("Don’t eat heavy meals before bed"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('6'),
                ),
              ),
              title: Text("Avoid nicotine"),
            ),
          ),
          Card(
            child: Text(
              "Finally, it can be helpful to create a consistent bedtime ritual, which helps signal to your brain and body that it’s time to sleep. Yours could be taking"
              " a shower and then reading a book or listening to some soft music",
              style: TextStyle(
                  fontStyle: FontStyle.italic,
                  color: Color.fromRGBO(10, 80, 160, 10)),
            ),
          ),
        ],
      ),
    );
  }
}
