import 'package:flutter/material.dart';

class About extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About Insomnia Health App'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            Card(
              elevation: 4.0,
              margin: EdgeInsets.all(10.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'About Insomnia Health App',
                      style: TextStyle(
                        fontSize: 24.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Divider(color: Colors.blue,),
                    SizedBox(height: 10.0),
                    Text(
                      'Welcome to the Insomnia Health App, developed by Aisha Muhammad for the final year project at Base University Abuja. This app is designed to help individuals manage and understand insomnia better.',
                      style: TextStyle(fontSize: 16.0),
                    ),
                  ],
                ),
              ),
            ),
            Card(
              elevation: 4.0,
              margin: EdgeInsets.all(10.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Features',
                      style: TextStyle(
                        fontSize: 20.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Divider(color: Colors.blue,),
                    SizedBox(height: 10.0),
                    Text(
                      '1. Medicine Reminder: This app includes a medicine reminder feature to help users keep track of their medication schedules.',
                      style: TextStyle(fontSize: 16.0),
                    ),
                    Text(
                      '2. Insomnia Information: Find detailed information about insomnia, including its causes, prevention, symptoms, and more.',
                      style: TextStyle(fontSize: 16.0),
                    ),
                    Text(
                      '3. Music Playlist: Enjoy a soothing music playlist designed to help with sleep and relaxation.',
                      style: TextStyle(fontSize: 16.0),
                    ),
                  ],
                ),
              ),
            ),
            Card(
              elevation: 4.0,
              margin: EdgeInsets.all(10.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Container(
                  width: MediaQuery.of(context).size.width -60,
                  child: Column(

                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        'Project Details',
                        style: TextStyle(
                          fontSize: 20.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Divider(color: Colors.blue,),
                      SizedBox(height: 10.0),

                      Text('Name: Aisha Muhammad', style: TextStyle(fontSize: 16.0)),
                      Text('Registration Number: -------', style: TextStyle(fontSize: 16.0)),
                      Text('Supervisor: Dr. Usman Bello Abubakar', style: TextStyle(fontSize: 16.0)),
                      Text('University: Base University Abuja', style: TextStyle(fontSize: 16.0)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
