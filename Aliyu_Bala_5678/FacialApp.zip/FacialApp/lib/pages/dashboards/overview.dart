import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class overview extends StatefulWidget {
  @override
  State<overview> createState() => _overviewState();
}

class _overviewState extends State<overview> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    String link = "assets/videos/ins1.mp4";
    super.initState();
    _controller = VideoPlayerController.asset(link,
        videoPlayerOptions: VideoPlayerOptions(allowBackgroundPlayback: true))
      ..initialize().then((_) {
        // Ensure the first frame is shown after the video is initialized, even before the play button has been pressed.
        setState(() {
          _controller.play();
        });
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Insomnia'),
        centerTitle: true,
      ),
      body: ListView(
        children: <Widget>[
          // Title Section
          Container(
            padding: EdgeInsets.all(20),
            child: Text(
              'Causes',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),

          // Image Section
          Card(
            margin: EdgeInsets.all(10),
            child: Image.asset('assets/images/cause3.png'),
          ),
          const Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              "Causes ",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            ),
          ),
          // Text Section
          Divider(
            color: Theme.of(context).primaryColor,
            thickness: 2,
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Card(
              child: Text("Chronic insomnia is usually a result of stress."
                  "life events or habits that disrupt sleep. Treating the underlying cause "
                  "can resolve the insomnia, but sometimes it can last for years. Some Causes May includes.."),
            ),
          ),
          const Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('1'),
                ),
              ),
              title: Text('Stress'),
              subtitle: Text("Concerns about work, school, health, finances "
                  "or family can keep your mind active at night, making it difficult to sleep. "
                  "Stressful life events or trauma — such as the death or illness of a loved one,"
                  " divorce, or a job loss — also may lead to insomnia."),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('2'),
                ),
              ),
              title: Text("Travel or work schedule."),
              subtitle: Text(
                  " Your circadian rhythms act as an internal clock, "
                  "guiding such things as your sleep-wake cycle, metabolism and body temperature"),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('3'),
                ),
              ),
              title: Text(
                  "Poor sleep habits. Poor sleep habits include an irregular bedtime schedule, "
                  "naps, stimulating activities before bed, an uncomfortable sleep environment, "),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('4'),
                ),
              ),
              title: Text(
                  "Eating too much late in the evening. Having a light snack before bedtime is OK,"
                  " but eating too much may cause you to feel physically uncomfortable while lying down. "),
            ),
          ),

          Card(
            child: Text(
              "Chronic insomnia may also be associated with medical conditions or the use of certain drugs."
              " Treating the medical condition may help improve sleep, "
              "but the insomnia may persist after the medical condition improves."
              "Additional common causes of insomnia include:",
              style: TextStyle(fontStyle: FontStyle.italic),
            ),
          ),
          Divider(
            color: Colors.blue,
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('1'),
                ),
              ),
              title: Text(
                  "Mental health disorders. Anxiety disorders, such as post-traumatic stress disorder, may disrupt your sleep."
                  " Awakening too early can be a sign of depression. Insomnia often occurs with other mental health disorders as well."),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('2'),
                ),
              ),
              title: Text(
                  "Medications. Many prescription drugs can interfere with sleep,"
                  " such as certain antidepressants and medications for asthma or blood pressure. "
                  "Many over-the-counter medications — such as some pain medications, "
                  "allergy and cold medications, and weight-loss products — contain caffeine and other stimulants that can disrupt sleep."),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('3'),
                ),
              ),
              title: Text(
                  "Medical conditions. Examples of conditions linked with insomnia include chronic pain, cancer, diabetes, heart disease,"
                  " asthma, gastroesophageal reflux disease (GERD), overactive thyroid, Parkinson's disease and Alzheimer's disease."),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('4'),
                ),
              ),
              title: Text(
                  "Sleep-related disorders. Sleep apnea causes you to stop breathing periodically throughout the night, interrupting your sleep. Restless legs syndrome causes unpleasant "
                  "sensations in your legs and an almost irresistible desire to move them, which may prevent you from falling asleep."),
            ),
          ),
          Card(
            child: ListTile(
              leading: CircleAvatar(
                child: Text(
                  ('5'),
                ),
              ),
              title: Text(
                  "Caffeine, nicotine and alcohol. Coffee, tea, cola and other caffeinated drinks are stimulants. "
                  "Drinking them in the late afternoon or evening can keep you from falling asleep at night."),
            ),
          ),
          // Video Section
        ],
      ),
    );
  }
}
