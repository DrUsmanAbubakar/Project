<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>NUBAPOLY CS E-Learning System - Students</title>
	<style>
		body {
			background-color: #f2f2f2;
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
		}

		header {
			background-color: #333;
			color: #fff;
			padding: 20px;
			text-align: center;
		}

		h1 {
			margin: 0;
			font-size: 36px;
			font-weight: normal;
			text-transform: uppercase;
		}

		nav {
			background-color: #666;
			color: #fff;
			padding: 10px;
		}

		nav ul {
			list-style-type: none;
			margin: 0;
			padding: 0;
			text-align: center;
		}

		nav li {
			display: inline-block;
			margin: 0 10px;
		}

		nav a {
			color: #fff;
			text-decoration: none;
			padding: 5px 10px;
		}

		nav a:hover {
			background-color: #fff;
			color: #333;
			border-radius: 5px;
		}

		main {
			margin: 20px;
			padding: 20px;
			background-color: #fff;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		}

		footer {
			background-color: #333;
			color: #fff;
			padding: 20px;
			text-align: center;
		}

		footer p {
			margin: 0;
		}

		table {
			width: 100%;
			border-collapse: collapse;
			margin-bottom: 20px;
		}

		th, td {
			padding: 10px;
			text-align: left;
			border-bottom: 1px solid #ddd;
		}

		th {
			background-color: #666;
			color: #fff;
		}

		td a {
			color: #333;
			text-decoration: none;
		}

		td a:hover {
			text-decoration: underline;
		}

		.filter {
			margin-bottom: 20px;
		}

		.filter label {
			font-weight: bold;
			margin-right: 10px;
		}

		.filter select {
			padding: 5px;
			font-size: 16px;
		}


	</style>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
</head>
<body>
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
			<li><a href="index.html">Home</a></li>
			<li><a href="courses.html">Courses</a></li>
			<li><a href="student.php">Students</a></li>
			<li><a href="faculty.html">Faculty</a></li>
			<li><a href="resources.html">Resources</a></li>
			<li><a href="admin login.html">Admin Login</a></li>
			<li><a href="register.html">Login</a></li>
		</ul>
	</nav>
	<main>
		<h2>Students</h2>
		<table>
			<thead>
				<tr>
					<th>ID</th>
					<th>Name</th>
					<th>Email</th>
					<th>Department</th>
				</tr>
			</thead>
			<tbody>
								<td>1</td>
				<td>John Doe</td>
				<td>johndoe@csnubapoly.edu.ng</td>
				<td>Information Technology</td>
			</tr>
			<tr>
				<td>2</td>
				<td>Jane Smith</td>
				<td>janesmith@csnubapoly.edu.ng</td>
				<td>Information Technology</td>
			</tr>
			<tr>
				<td>3</td>
				<td>Michael Johnson</td>
				<td>michaeljohnson@csnubapoly.edu.ng</td>
				<td>Information Technology</td>
			</tr>
			<tr>
				<td>4</td>
				<td>Sarah Williams</td>
				<td>sarahwilliams@csnubapoly.edu.ng</td>
				<td>Information Technology</td>
			</tr>
			<tr>
				<td>5</td>
				<td>David Brown</td>
				<td>davidbrown@csnubapoly.edu.ng</td>
				<td>Information Technology</td>
			</tr>
		</tbody>
	</table>
	<div class="filter">
		<label for="department-filter">Filter by department:</label>
		<select id="department-filter">
			<option value="">All</option>
			<option value="it">Information Technology</option>
			<option value="cs">Computer Science</option>
			<option value="se">Software Engineering</option>
		</select>
	</div>
</main>
<footer>
	<p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved</p>
</footer>
<script>
	// filter students by department
	const departmentFilter = document.getElementById('department-filter');
	const rows = document.querySelectorAll('tbody tr');
	departmentFilter.addEventListener('change', function() {
		const selectedDepartment = departmentFilter.value;
		for (let row of rows) {
			const department = row.querySelector('td:last-child').textContent.toLowerCase();
			if (selectedDepartment === '' || selectedDepartment === department) {
				row.style.display = '';
			} else {
				row.style.display = 'none';
			}
		}
	});
</script>
</body>
</html>
