<?php

session_start();

include_once '../connection.php';


if ( !isset($_SESSION['loggedInAdmin']) ) {
	header('location: ../login_admin.php');exit;
}

$sql = "SELECT * FROM `handout`";
$handouts_r = $dbc->query( $sql );

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>NUBAPOLY CS E-Learning System - Faculty</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
		<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="students.php">Students</a></li>
            <li><a href="co_list.php">List of Carry Over</a></li>
            <li><a href="carry_over.php">Add Carry Over </a></li>
			<li><a href="add_material.php">Add Material</a></li>
			<li><a href="faculty.php">Faculty</a></li>
			<li><a href="resources.php">Resources</a></li>
			<li><a href="assignments.php">Assignments</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
	<main>
		<h2>Resources</h2>
		<div class="filter">
			<label>Filter by Category:</label>
			<select id="category-filter">
				<option value="">All</option>
				<option value="programming">Programming</option>
				<option value="networking">Networking</option>
				<option value="database">Database</option>
			</select>
		</div>
		<table id="resources-table">
			<thead>
				<tr>
					<th>S/N</th>
					<th>Resource Name</th>
					<th>Category</th>
					<th>Description</th>
					<th>Link</th>
				</tr>
			</thead>
			<tbody>
				<?php
					$sn = 1;
					while ( $handout = $handouts_r->fetch_assoc() ) {
						$title = $handout['title'];
						$category = $handout['category'];
						$description = $handout['description'];
						$filename = strtolower($handout['filename']);
						?>
						<tr>
							<td><?= $sn++;?></td>
							<td><?= ucwords($title);?></td>
							<td><?= ucfirst($category);?></td>
							<td><?= ucfirst($description);?></td>
							<td><a href="../resources/handouts/<?= $filename ?>">cs.nubapoly.edu.ng/resources/<?=$filename?></a></td>
						</tr>
						<?php
					}
				?>
			</tbody>
		</table>
	</main>
	<footer>
		<p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved</p>
	</footer>
	<script src="script.js"></script>
</body>
</html>