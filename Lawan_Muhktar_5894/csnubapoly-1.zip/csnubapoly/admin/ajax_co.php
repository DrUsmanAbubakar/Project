<?php
include_once '../connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data from the AJAX request and sanitize it
    $studentID = isset($_POST['student_id']) ? intval($_POST['student_id']) : 0;
    $coStatus = isset($_POST['co_status']) ? intval($_POST['co_status']) : 0;
    $courseID = isset($_POST['course_id']) ? intval($_POST['course_id']) : 0;

    // Check if the provided values are valid
    if ($studentID <= 0 || ($coStatus !== 0 && $coStatus !== 1) || $courseID <= 0) {
        echo "Invalid input data"; // Handle invalid data
        exit;
    }

    // Ensure you have a valid database connection
    if ($dbc->connect_error) {
        die("Connection failed: " . $dbc->connect_error);
    }

    // Perform the SQL update based on the CO status and student ID
    $sql = "UPDATE couse_reg SET c_o = ? WHERE student_id = ? AND course_id = ?";
    $stmt = $dbc->prepare($sql);
    $stmt->bind_param('iii', $coStatus, $studentID, $courseID);

    if ($stmt->execute()) {
        echo "Success"; // Send a success message back to the AJAX request
    } else {
        echo "Error: " . $stmt->error; // Send an error message back to the AJAX request
    }

    $stmt->close();
    $dbc->close();
}
?>
