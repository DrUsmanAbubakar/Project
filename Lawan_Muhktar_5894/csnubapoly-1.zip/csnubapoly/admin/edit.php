<?php
include 'config.php'; // Include your database connection configuration

function getCourseById($id)
{
    global $dbc;
    $query = "SELECT * FROM courses WHERE id=$id";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Query failed: " . mysqli_error($dbc));
        return false;
    }

    return mysqli_fetch_assoc($result);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $course = getCourseById($id);
    if (!$course) {
        showError("Course not found!");
    }
} else {
    showError("Invalid request!");
    exit;
}

if (isset($_POST['update_course'])) {
    $course_code = $_POST['course_code'];
    $course_title = $_POST['course_title'];
    $instructor_id = $_POST['instructor'];
    $credit_hours = $_POST['credit_hours'];

    if (updateCourse($id, $course_code, $course_title, $instructor_id, $credit_hours)) {
        echo '<div class="alert alert-success" role="alert">Course updated successfully!</div>';
        $course = getCourseById($id); // Refresh course data after update
    } else {
        echo '<div class="alert alert-danger" role="alert">Error updating course. Please try again.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h1>Edit Course</h1>

        <form action="" method="post">
            <div class="form-group">
                <label for="course_code">Course Code:</label>
                <input type="text" name="course_code" value="<?php echo $course['course_code']; ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="course_title">Course Title:</label>
                <input type="text" name="course_title" value="<?php echo $course['course_title']; ?>" class="form-control" required>
            </div>

            <!-- Fetch Instructors from Database -->
            <div class="form-group">
                <label for="instructor">Instructor:</label>
                <select name="instructor" class="form-control" required>
                    <?php
                    $instructorsResult = getInstructors();
                    if ($instructorsResult) {
                        while ($instructor = mysqli_fetch_assoc($instructorsResult)) {
                            $selected = ($instructor['id'] == $course['instructor_id']) ? 'selected' : '';
                            echo "<option value='{$instructor['id']}' $selected>{$instructor['name']}</option>";
                        }
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="credit_hours">Credit Hours:</label>
                <input type="number" name="credit_hours" value="<?php echo $course['credit_hours']; ?>" class="form-control" required>
            </div>
            <a href="courses.php" class="btn btn-primary"><- Back to Course List</a>

            <button type="submit" name="update_course" class="btn btn-success">Update Course</button>

        </form>
    </div>

    <!-- Include Bootstrap JS and Popper.js -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>
