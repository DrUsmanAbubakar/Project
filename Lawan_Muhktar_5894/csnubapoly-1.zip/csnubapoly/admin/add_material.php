<?php
session_start();

include_once '../connection.php';

if (!isset($_SESSION['loggedInAdmin'])) {
    header('location: ../login_admin.php');
    exit;
}

if (isset($_POST['action'])) {
    $action = $dbc->real_escape_string($_POST['action']);

    switch ($action) {
        case 'upload':
            $title = $dbc->real_escape_string($_POST['title']);
            $category = $dbc->real_escape_string($_POST['category']);
            $description = $dbc->real_escape_string($_POST['description']);
            $course_id = $dbc->real_escape_string($_POST['course_id']);

            $handout = $_FILES['handout'];
            $name_arr = explode('.', $handout['name']);
            $file_extension = strtolower(end($name_arr));

            if ($file_extension === 'pdf') {  // Ensure it's a PDF file
                $filename = uniqid() . '.' . $file_extension;
                $save_path = "../resources/handouts";

                $save_file = move_uploaded_file($handout['tmp_name'], "$save_path/$filename");

                if ($save_file) {
                    $upload_sql = "INSERT INTO `handout`(`title`, `category`, `description`, `course_id`, `filename`)
                    VALUES('$title', '$category', '$description', '$course_id', '$filename')";
                    $upload_r = $dbc->query($upload_sql);
                }
            }

            header("location: add_material.php");
            exit;
            break;
    }
}

$handout_sql = "SELECT * FROM `handout`";
$handout_r = $dbc->query($handout_sql);

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>NUBAPOLY CS E-Learning System - Handouts</title>
    <!-- Include your CSS file references here -->
    <link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
</head>
<body>
    <header>
        <img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
        <h1>NUBAPOLY CS E-Learning System</h1>
    </header>
    <nav>
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="students.php">Students</a></li>
            <li><a href="co_list.php">List of Carry Over</a></li>
            <li><a href="carry_over.php">Add Carry Over </a></li>
            <li><a href="add_material.php">Add Material</a></li>
            <li><a href="grades.php">View Grades </a></li>
            <li><a href="resources.php">Resources</a></li>
            <li><a href="handouts.php">Handouts</a></li>
            <li><a href="assignments.php">Assignments</a></li>
            <li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <section class="container">
            <h2>Upload Handout</h2>
            <div style="width: 50%;">
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="upload">
                    <label for="handout-title">Handout Title:</label>
                    <input id="handout-title" type="text" name="title" placeholder="Handout title" required>

                    <label for="handout-category">Category:</label>
                    <input id="handout-category" type="text" name="category" placeholder="Category" required>

                    <label for="handout-description">Description:</label>
                    <input id="handout-description" type="text" name="description" placeholder="Description" required>

                    <label for="course">Select Course:</label>
                    <select id="course" name="course_id" class="sel">
                        <option value="">--Select Course--</option>
                        <?php
                        $courses_r = $dbc->query("SELECT `id`, `code`,`title` FROM `course`");
                        while ($course = $courses_r->fetch_assoc()) {
                            $id = $course['id'];
                            $code = strtoupper($course['code']);
                            $title = strtoupper($course['title']);
                        ?>
                            <option value="<?= $id; ?>"><?= $code; ?> <?= $title; ?>  Material </option>
                        <?php
                        }
                        ?>
                    </select>

                    <label for="handout-file">Upload PDF:</label>
                    <input type="file" id="handout-file" name="handout" accept=".pdf" required>

                    <input type="submit" value="Upload Handout" class="submit-button">
                </form>
            </div>
        </section>
        <section class="container">
            <h2>Available Handouts</h2>
            <table class="handouts">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th width="25%">Handout Title</th>
                        <th width="20%">Category</th>
                        <th width="20%">Description</th>
                        <th width="10%">Course ID</th>
                        <th width="25%">Handout File</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        if ($handout_r->num_rows > 0) {
                            $sn = 1;
                            while ($handout = $handout_r->fetch_assoc()) {
                                $title = $handout['title'];
                                $category = $handout['category'];
                                $description = $handout['description'];
                                $course_id = $handout['course_id'];
                                $filename = $handout['filename'];
                    ?>
                                <tr>
                                    <td><?= $sn++; ?></td>
                                    <td><?= $title; ?></td>
                                    <td><?= $category; ?></td>
                                    <td><?= $description; ?></td>
                                    <td><?= $course_id; ?></td>
                                    <td>
                                        <a target="_blank" href="../resources/handouts/<?= $filename; ?>">
                                            View Handout
                                        </a>
                                    </td>
                                </tr>
                    <?php
                            }
                        } else {
                    ?>
                            <tr>
                                <td colspan="6">No handouts available.</td>
                            </tr>
                    <?php
                        }
                    ?>
                </tbody>
            </table>
        </section>
    </main>
    <footer>
        <p>&copy; 2023 MAAUN CS E-Learning System. All rights reserved.</p>
    </footer>
</body>
</html>
