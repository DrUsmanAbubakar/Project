<?php
session_start();

include_once '../connection.php';


if ( !isset($_SESSION['loggedInAdmin']) ) {
	header('location: ../login_admin.php');exit;
}

// Handle approval or rejection
if (isset($_POST['action'])) {
    $studentId = $_POST['student_id'];

    if ($_POST['action'] === 'approved') {
        $updateSql = "UPDATE `student` SET `status` = 'approved' WHERE `id` = $studentId";
    } elseif ($_POST['action'] === 'rejected') {
        $updateSql = "UPDATE `student` SET `status` = 'rejected' WHERE `id` = $studentId";
    }

    $updateResult = $dbc->query($updateSql);

    if ($updateResult === false) {
        die("Error: " . $dbc->error);
    }
}

// Fetch all students for the admin page
$sql = "SELECT * FROM `student`";
$result = $dbc->query($sql);

if ($result === false) {
    die("Error: " . $dbc->error);
}

$students = $result->fetch_all(MYSQLI_ASSOC);

// Close the database connection
$dbc->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <!-- Include necessary CSS and JS libraries for DataTables -->
    <meta charset="UTF-8">
	<title>Nubapoly CS E-Learning System - Students</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.css">
    <script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.js"></script>
    <style>
    .status-approved {
        background-color: green;
        color: white;
    }

    .status-rejected {
        background-color: red;
        color: white;
    }

    .status-pending {
        background-color: yellow;
        color: black; /* Change the text color for pending status */
    }

    .hidden {
        display: none;
    }
</style>
</head>
<body>

<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
			<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="students.php">Students</a></li>
            <li><a href="co_list.php">List of Carry Over</a></li>
            <li><a href="carry_over.php">Add Carry Over </a></li>
            <li><a href="carry_over.php">View Grades </a></li>
			<li><a href="resources.php">Resources</a></li>
			<li><a href="assignments.php">Assignments</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
    <br>
<div class="col-lg16 mx-auto">
<table id="studentsTable" class="display">
    <thead>
        <tr>
            <th>ID</th>
            <th>Registration Number</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Level</th>
            <th>Department</th>
           
            <th>WAEC</th>
            <th>JAMB</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($students as $student): ?>
            <tr>
                <td><?= $student['id'] ?></td>
                <td><?= $student['std_reg'] ?></td>
                <td><?= $student['fname'] ?></td>
                <td><?= $student['lname'] ?></td>
                <td><?= $student['email'] ?></td>
                <td><?= $student['level'] ?></td>
                <td><?= $student['department'] ?></td>
                <td>
                    <a href="../readfile.php?file=<?= $student['waec_upload'] ?>" target="_blank">View WAEC</a>
                </td>
                <td>
                    <a href="../readfile.php?file=<?= $student['jamb_upload'] ?>" target="_blank">View JAMB</a>
                </td>
                <td class="status-<?= strtolower($student['status']) ?>"><?= $student['status'] ?></td>

                <td>
                    <form method="post" class="<?= ($student['status'] === 'approved' || $student['status'] === 'reject') ? 'hidden' : ''; ?>">
                        <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
                        <button type="submit" name="action" value="approved">Approve</button>
                        <button type="submit" name="action" value="rejected">Reject</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<script>
    $(document).ready(function () {
        $('#studentsTable').DataTable();
    });
</script>
<div class="filter">
            <label for="department-filter">Filter by department:</label>
            <select id="department-filter">
                <option value="">All</option>
                <option value="Information Technology">Information Technology</option>
                <option value="Cyber Security">Cyber Security</option>
                <option value="Software Engineering">Software Engineering</option>
            </select>
        </div>
    </main>
    <footer>
        <p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
        $('.co-button').click(function() {
        const studentID = $(this).data('student-id');
        const coStatus = $(this).data('co-status');

        // Send an AJAX request to update the CO status
        $.ajax({
            type: 'POST',
            url: 'ajax_co.php', // Create this PHP file
            data: {
                student_id: studentID,
                co_status: coStatus
            },
            success: function(response) {
                 // Handle the response
                 if (response === 'Success') {
                    // Display a success alert
                    alert('CO status updated successfully.');
                } else {
                    // Display an error alert
                    alert('An error occurred while updating CO status.');
                }
            },
            error: function(xhr, status, error) {
                // Handle errors here
                console.error(error);
            }
        });
    });
});


        // Filter students by department
        const departmentFilter = document.getElementById('department-filter');
        const rows = document.querySelectorAll('tbody tr');

        departmentFilter.addEventListener('change', function () {
            const selectedDepartment = departmentFilter.value;

            for (let row of rows) {
                const departmentCell = row.querySelector('td:nth-child(4)').textContent; // Extract the department cell value

                if (selectedDepartment === '' || selectedDepartment === departmentCell) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    </script>
</div>
</body>
</html>
