<?php
include 'config.php'; // Include your database connection configuration

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    if (isset($_POST['confirm_delete'])) {
        if (deleteCourse($id)) {
            echo '<div class="alert alert-success" role="alert">Course deleted successfully!</div>';
            echo '<a href="courses.php" class="btn btn-primary">Back to Course List</a>';
            exit;
        } else {
            echo '<div class="alert alert-danger" role="alert">Error deleting course. Please try again.</div>';
        }
    }
} else {
    showError("Invalid request!");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Course</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h1>Delete Course</h1>

        <p>Are you sure you want to delete this course?</p>
        <form action="" method="post">
            <button type="submit" name="confirm_delete" class="btn btn-danger">Yes, Delete</button>
        </form>

        <a href="courses.php" class="btn btn-primary">Back to Course List</a>
    </div>

    <!-- Include Bootstrap JS and Popper.js -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>
