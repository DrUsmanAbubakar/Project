<?php

session_start();

include_once '../connection.php';


if ( !isset($_SESSION['loggedInAdmin']) ) {
	header('location: ../login_admin.php');exit;
}

$sql = "SELECT * FROM `student`";
$students_r = $dbc->query( $sql );

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Nubapoly CS E-Learning System - Students</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
</head>
<body>
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
		<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="students.php">Students</a></li>
            <li><a href="co_list.php">List of Carry Over</a></li>
            <li><a href="carry_over.php">Add Carry Over </a></li>
            <li><a href="add_material.php">Add Material</a></li>
			<li><a href="grades.php">View Grades </a></li>
			<li><a href="resources.php">Resources</a></li>
			<li><a href="assignments.php">Assignments</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
	<main>
        <h2>Students Carry Over</h2>
       <!-- Inside the existing table, add an additional column for courses -->
<!-- Inside the existing table, add a new row for courses and a column for student name -->
<table>
    <thead>
        <tr>
            <th>S/N</th>
            <th>Student ID</th>
            <th>Student Name</th>
            <th>Email</th>
            <th>Department</th>
            <th>Level</th>
                  
            <th>Courses</th>
            <th>Carry Over</th>
        </tr>
    </thead>
    <tbody>
    <?php
        $sql = "SELECT * FROM couse_reg";
        $courses_r = $dbc->query($sql);
        $sn = 1;
        
        while ($course = $courses_r->fetch_assoc()) {
            $studentID = $course['student_id'];
            $course_id = $course['course_id'];

            // Fetch and display student information
            $studentSql = "SELECT fname,id, lname, email, department, level FROM student WHERE id = $studentID";
            $studentResult = $dbc->query($studentSql);

            if ($student = $studentResult->fetch_assoc()) {
                $name = ucwords($student['fname'] . ' ' . $student['lname']);
                $email = strtolower($student['email']);
                $department = ucfirst($student['department']);
                $level = ucwords($student['level']);
              
                
                // Display student information
                ?>
                <tr>  <td><?= $sn++; ?></td>
                    <td><?= $student['id']; ?></td>
                    <td><?= $name; ?></td>
                    <td><?= $email; ?></td>
                    <td><?= $department; ?></td>
                    <td><?= $level; ?></td>
              
                   
                    <td>
                        <?php
                            // Fetch and display the course name for the current student
                            $courseNameSql = "SELECT title FROM course WHERE id = $course_id";
                            $courseNameResult = $dbc->query($courseNameSql);
                            if ($courseName = $courseNameResult->fetch_assoc()) {
                                echo ucwords($courseName['title']);
                            }
                        ?>
                    </td>
                    <td>
                        <button class="co-button btn btn-danger" data-course-id="<?= $course_id; ?>" data-student-id="<?= $studentID; ?>" data-co-status="1">CO</button>
                    </td>
                </tr>
            <?php
            }
        }
    ?>
</tbody>

</table>

        <div class="filter">
            <label for="department-filter">Filter by department:</label>
            <select id="department-filter">
                <option value="">All</option>
                <option value="Information Technology">Information Technology</option>
                <option value="Cyber Security">Cyber Security</option>
                <option value="Software Engineering">Software Engineering</option>
            </select>
        </div>
    </main>
    <footer>
        <p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
    $('.co-button').click(function() {
        const studentID = $(this).data('student-id');
        const coStatus = $(this).data('co-status');
        const courseID = $(this).data('course-id'); // Added to get the course ID

        // Send an AJAX request to update the CO status for the specific course
        $.ajax({
            type: 'POST',
            url: 'ajax_co.php',
            data: {
                student_id: studentID,
                co_status: coStatus,
                course_id: courseID // Pass the course ID in the request
            },
            success: function(response) {
                // Handle the response
                if (response === 'Success') {
                    // Display a success alert
                    alert('CO status updated successfully for Course ID: ' + courseID);
                } else {
                    // Display an error alert
                    alert('An error occurred while updating CO status.');
                }
                
                // You can perform other actions here based on the response.
            },
            error: function(xhr, status, error) {
                // Handle errors here
                console.error(error);
                alert('An error occurred during the request.');
            }
        });
    });
});


        // Filter students by department
        const departmentFilter = document.getElementById('department-filter');
        const rows = document.querySelectorAll('tbody tr');

        departmentFilter.addEventListener('change', function () {
            const selectedDepartment = departmentFilter.value;

            for (let row of rows) {
                const departmentCell = row.querySelector('td:nth-child(4)').textContent; // Extract the department cell value

                if (selectedDepartment === '' || selectedDepartment === departmentCell) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    </script>
</body>
</html>