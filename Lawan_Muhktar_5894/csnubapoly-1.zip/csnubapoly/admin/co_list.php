<?php

session_start();

include_once '../connection.php';


if ( !isset($_SESSION['loggedInAdmin']) ) {
	header('location: ../login_admin.php');exit;
}

$sql = "SELECT * FROM `student`";
$students_r = $dbc->query( $sql );

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Nubapoly CS E-Learning System - Students</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
    <style>
    /* Style for "CO" status (Red) */
    .co-red {
        color: red;
    }

    /* Style for "No CO" status (Green) */
    .co-green {
        color: green;
    }
</style>

</head>
<body>
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
		<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="students.php">Students</a></li>
            <li><a href="co_list.php">List of Carry Over</a></li>
            <li><a href="carry_over.php">Add Carry Over </a></li>
            <li><a href="add_material.php">Add Material</a></li>
            <li><a href="grades.php">View Grades </a></li>
			<li><a href="resources.php">Resources</a></li>
			<li><a href="assignments.php">Assignments</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
	<main>
        <h2>List of Students Carry Over</h2>
       <!-- Inside the existing table, add an additional column for courses -->
<!-- Inside the existing table, add a new row for courses and a column for student name -->
<table>
    <thead>
        <tr>
            <th>S/N</th>
            <th>Student Name</th>
            <th>Email</th>
            <th>Department</th>
            <th>Level</th>
             
            <th>Courses</th>
            <th>Carry Over Status</th>
        </tr>
    </thead>
    <tbody>
    <?php
        $sql = "SELECT * FROM couse_reg";
        $courses_r = $dbc->query($sql);
        $sn = 1;
        
        while ($course = $courses_r->fetch_assoc()) {
            $studentID = $course['student_id'];
            $course_id = $course['course_id'];

            // Fetch and display student information
            $studentSql = "SELECT fname, lname, email, department, level FROM student WHERE id = $studentID";
            $studentResult = $dbc->query($studentSql);

            if ($student = $studentResult->fetch_assoc()) {
                $name = ucwords($student['fname'] . ' ' . $student['lname']);
                $email = strtolower($student['email']);
                $department = ucfirst($student['department']);
                $level = ucwords($student['level']);
         
                
                // Display student information
                ?>
                <tr>
                    <td><?= $sn++; ?></td>
                    <td><?= $name; ?></td>
                    <td><?= $email; ?></td>
                    <td><?= $department; ?></td>
                    <td><?= $level; ?></td>
              
                   
                    <td>
                        <?php
                            // Fetch and display the course name for the current student
                            $courseNameSql = "SELECT title FROM course WHERE id = $course_id";
                            $courseNameResult = $dbc->query($courseNameSql);
                            if ($courseName = $courseNameResult->fetch_assoc()) {
                                echo ucwords($courseName['title']);
                            }
                        ?>
                    </td>
                  <!-- Inside the loop for fetching student information -->
                  <td>
                        <?php
                        // Fetch the carry-over status for the current student from couse_reg
                        $carryOverStatusSql = "SELECT c_o FROM couse_reg WHERE student_id = $studentID";
                        $carryOverStatusResult = $dbc->query($carryOverStatusSql);
                        if ($carryOverStatus = $carryOverStatusResult->fetch_assoc()) {
                            // Check if the carry-over status is 1 (CO) or 0 (No CO)
                            $carryOver = ($carryOverStatus['c_o'] == 1) ? 'CO' : 'No CO';

                            // Add the appropriate CSS class based on the status
                            $statusClass = ($carryOverStatus['c_o'] == 1) ? 'co-red' : 'co-green';

                            echo '<span class="' . $statusClass . '">' . $carryOver . '</span>';
                        }
                        ?>
                    </td>


                </tr>
            <?php
            }
        }
    ?>
</tbody>

</table>

        <div class="filter">
            <label for="department-filter">Filter by department:</label>
            <select id="department-filter">
                <option value="">All</option>
                <option value="Information Technology">Information Technology</option>
                <option value="Cyber Security">Cyber Security</option>
                <option value="Software Engineering">Software Engineering</option>
            </select>
        </div>
    </main>
    <footer>
        <p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <script>

        // Filter students by department
        const departmentFilter = document.getElementById('department-filter');
        const rows = document.querySelectorAll('tbody tr');

        departmentFilter.addEventListener('change', function () {
            const selectedDepartment = departmentFilter.value;

            for (let row of rows) {
                const departmentCell = row.querySelector('td:nth-child(4)').textContent; // Extract the department cell value

                if (selectedDepartment === '' || selectedDepartment === departmentCell) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    </script>
</body>
</html>