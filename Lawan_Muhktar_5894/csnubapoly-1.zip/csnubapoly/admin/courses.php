<?php

session_start();

include_once '../connection.php';


if ( !isset($_SESSION['loggedInAdmin']) ) {
	header('location: ../login_admin.php');exit;
}

$sql = "SELECT * FROM `course`";
$courses_r = $dbc->query( $sql );

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Nubapoly CS E-Learning System - Courses</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">

	<style>
        .add-form {
            display: none;
        }
    </style>
</head>
<body>
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
		<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="students.php">Students</a></li>
			<li><a href="instructors/index.php">instructors</a></li>
            <li><a href="co_list.php">List of Carry Over</a></li>
            <li><a href="carry_over.php">Add Carry Over </a></li>
			<li><a href="add_material.php">Add Material</a></li>
			<li><a href="grades.php">View Grades </a></li>
			<li><a href="resources.php">Resources</a></li>
			<li><a href="assignments.php">Assignments</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
	<main>
	
	<div class="container">
	<div class="row">
		<div class="col">
			<button id="toggleAddForm" class="btn btn-primary">Add Course</button>
		</div>
	</div>

	<!-- Add Course Form -->
	<form id="addForm" class="add-form" action="" method="post">
		<div class="row">
			<div class="col">
				<label for="course_code">Course Code:</label>
				<input type="text" name="course_code" class="form-control" required>
			</div>
			<div class="col">
				<label for="course_title">Course Title:</label>
				<input type="text" name="course_title" class="form-control" required>
			</div>
		</div>

		<!-- Fetch Instructors from Database -->
		<div class="row">
			<div class="col">
				<label for="instructor">Instructor:</label>
				<select name="instructor" class="form-control" required>
					<?php
					include 'config.php'; // Include your database connection configuration
					$instructorsResult = getInstructors();
					if ($instructorsResult) {
						while ($instructor = mysqli_fetch_assoc($instructorsResult)) {
							echo "<option value='{$instructor['id']}'>{$instructor['name']}</option>";
						}
					}
					?>
				</select>
			</div>
			<div class="col">
				<label for="credit_hours">Credit Hours:</label>
				<input type="number" name="credit_hours" class="form-control" required>
			</div>
		</div>

		<div class="row">
			<div class="col">
				<button type="submit" name="add_course" class="btn btn-success">Save Course</button>
			</div>
		</div>
	</form>
</div>

<?php
// Add Course
if (isset($_POST['add_course'])) {
	$course_code = $_POST['course_code'];
	$course_title = $_POST['course_title'];
	$instructor_id = $_POST['instructor'];
	$credit_hours = $_POST['credit_hours'];

	if (addCourse($course_code, $course_title, $instructor_id, $credit_hours)) {
		echo '<div class="alert alert-success" role="alert">Course added successfully!</div>';

	}
}
?>

	<table id="courses_table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Course Code</th>
                <th>Course Title</th>
                <th>Instructor</th>
                <th>Credit Hours</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $result = getCourses();
            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>{$row['id']}</td>";
                    echo "<td>{$row['course_code']}</td>";
                    echo "<td>{$row['course_title']}</td>";
                    echo "<td>{$row['instructor_name']}</td>";
                    echo "<td>{$row['credit_hours']}</td>";
                    echo "<td><a href='edit.php?id={$row['id']}' class='btn btn-primary'>Edit</a> | <a href='delete.php?id={$row['id']}' class='btn btn-danger'>Delete</a></td>";
                    echo "</tr>";
                }
            }
            ?>
        </tbody>
    </table>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function () {
            $('#courses_table').DataTable();

            // Toggle Add Course Form
            $('#toggleAddForm').on('click', function () {
                $('#addForm').toggle();
            });
        });
    </script>
</main>
<footer>
	<p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved</p>
</footer>
</body>
</html>