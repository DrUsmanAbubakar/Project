<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>NUBAPOLY CS E-Learning System - Faculty</title>
	<style>
		body {
			background-color: #f2f2f2;
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
		}

		header {
			background-color: green;
			color: #fff;
			padding: 20px;
			text-align: center;
		}

		h1 {
			margin: 0;
			font-size: 36px;
			font-weight: normal;
			text-transform: uppercase;
		}

		nav {
			background-color: green;
			color: #fff;
			padding: 10px;
		}

		nav ul {
			list-style-type: none;
			margin: 0;
			padding: 0;
			text-align: center;
		}

		nav li {
			display: inline-block;
			margin: 0 10px;
		}

		nav a {
			color: #fff;
			text-decoration: none;
			padding: 5px 10px;
		}

		nav a:hover {
			background-color: #fff;
			color: #333;
			border-radius: 5px;
		}

		main {
			margin: 20px;
			padding: 20px;
			background-color: #fff;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		}

		footer {
			background-color: green;
			color: #fff;
			padding: 20px;
			text-align: center;
		}

		footer p {
			margin: 0;
		}

		table {
			width: 100%;
			border-collapse: collapse;
			margin-bottom: 20px;
		}

		th, td {
			padding: 10px;
			text-align: left;
			border-bottom: 1px solid #ddd;
		}

		th {
			background-color: green;
			color: #fff;
		}

		td a {
			color: #333;
			text-decoration: none;
		}

		td a:hover {
			text-decoration: underline;
		}

		.filter {
			margin-bottom: 20px;
		}

		.filter label {
			font-weight: bold;
			margin-right: 10px;
		}

		.filter select {
			padding: 5px;
			font-size: 16px;
		}
	</style>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
</head>
<body>
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
		<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="students.php">Students</a></li>
            <li><a href="co_list.php">List of Carry Over</a></li>
            <li><a href="carry_over.php">Add Carry Over </a></li>
			<li><a href="faculty.php">Faculty</a></li>
			<li><a href="resources.php">Resources</a></li>
			<li><a href="assignments.php">Assignments</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
	<main>
		<h2>Faculty</h2>
		<table>
			<thead>
				<tr>
					<th>ID</th>
					<th>Name</th>
					<th>Email</th>
					<th>Department</th>
				</tr>
			</thead>
			<tbody>

<div class="filter">
<label for="category">Filter by category:</label>
<select id="category">
<option value="all">All</option>
<option value="lecture">Lecture Notes</option>
<option value="assignment">Assignments</option>
<option value="project">Projects</option>
</select>
</div>
<div class="resources">
<h2>Lecture Notes</h2>
<ul>
<li><a href="#">Introduction to HTML</a></li>
<li><a href="#">CSS Fundamentals</a></li>
<li><a href="#">JavaScript Basics</a></li>
</ul>
</div>
<div class="resources">
<h2>Assignments</h2>
<ul>
<li><a href="#">HTML/CSS Assignment 1</a></li>
<li><a href="#">JavaScript Assignment 1</a></li>
<li><a href="#">Web Development Project Proposal</a></li>
</ul>
</div>
<div class="resources">
<h2>Projects</h2>
<ul>
<li><a href="#">Web Development Project 1</a></li>
<li><a href="#">Mobile Application Project 1</a></li>
<li><a href="#">Database Project 1</a></li>
</ul>
</div>
</main>
<footer>
<p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved</p>
</footer>

</body>
</html>