<?php

session_start();

include_once '../connection.php';

if (!isset($_SESSION['loggedInAdmin'])) {
    header('location: ../login_admin.php');
    exit;
}

if (isset($_POST['action'])) {
    $action = $dbc->real_escape_string($_POST['action']);

    switch ($action) {
        case 'grade':
            $grade = $dbc->real_escape_string($_POST['grade']);
            $id = $dbc->real_escape_string($_POST['id']);

            if (isset($grade) && is_numeric($grade)) {
                $grade_sql = "UPDATE `assignment_submission`
                SET `grade`='$grade',`status`='Approved'
                WHERE `id`='$id'";
                $grade_r = $dbc->query($grade_sql);
            }

            header("location: assignments.php");
            exit;
            break;

        case 'upload':
            $code = $dbc->real_escape_string($_POST['code']);
            $title = strtolower($dbc->real_escape_string($_POST['title']));
            $date = $dbc->real_escape_string($_POST['date']);

            $assignment = $_FILES['assignment'];
            $name_arr = explode('.', $assignment['name']);
            $filename = strtolower($code) . "_$title." . end($name_arr);
            $filename = str_replace(' ', '_', $filename);
            $title = strtoupper($code) . " $title";
            $save_path = "../resources/assignments";

            $save_file = move_uploaded_file($assignment['tmp_name'], "$save_path/$filename");

            $upload_sql = "INSERT INTO `assignment_schedule`(`title`,`ends_at`,`filename`)
            VALUES('$title','$date','$filename')";
            $upload_r = $dbc->query($upload_sql);

            header("location: assignments.php");
            exit;

            break;
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'end') {

    $id = $dbc->real_escape_string($_GET['id']);

    $end_assignment_sql = "UPDATE `assignment_schedule`
    SET `status`='0', `ended_at`=CURRENT_TIMESTAMP()
    WHERE `id`='$id'";
    $end_assignment_r = $dbc->query($end_assignment_sql);

    header("location: assignments.php");
    exit;
}

$assignment_schedule_sql = "SELECT *
FROM `assignment_schedule` `as`
WHERE `status`='1'";
$assignment_schedule_r = $dbc->query($assignment_schedule_sql);

$assignment_submission_sql = "SELECT `asu`.`id`,`asu`.`filename`,`s`.`fname`,`s`.`lname`,`asc`.`title`
FROM `assignment_submission` `asu`
INNER JOIN `assignment_schedule` `asc` ON `asu`.`scheduled_assignment_id`=`asc`.`id`
INNER JOIN `student` `s` ON `asu`.`student_id`=`s`.`id`
WHERE `grade` IS NULL";
$assignment_submission_r = $dbc->query($assignment_submission_sql);

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>NUBAPOLY CS E-Learning System - Assignment Submission</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
</head>
<body>
    <header>
        <img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
        <h1>NUBAPOLY CS E-Learning System</h1>
    </header>
    <nav>
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="students.php">Students</a></li>
            <li><a href="co_list.php">List of Carry Over</a></li>
            <li><a href="carry_over.php">Add Carry Over </a></li>
			<li><a href="add_material.php">Add Material</a></li>
            <li><a href="grades.php">View Grades </a></li>
            <li><a href="resources.php">Resources</a></li>
            <li><a href="assignments.php">Assignments</a></li>
            <li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <section class="container">
            <h2>Schedule New Assignment</h2>
            <div style="width: 50%;">
                <form id="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="upload">
                    <label for="course">Course</label>
                    <select id="course" name="code" class="sel">
                        <option value="">--Select Course--</option>
                        <?php
                            $courses_r = $dbc->query("SELECT `code` FROM `course`");
                            while ($course = $courses_r->fetch_assoc()) {
                                $code = strtoupper($course['code']);
                        ?>
                                <option value="<?= $code; ?>"><?= $code; ?> Assignment</option>
                        <?php
                            }
                        ?>
                    </select>

                    <label for="assignment">Upload FIle:</label>
                    <input type="file" id="assignment" name="assignment" required>

                    <label for="ass-title">Assignment Title:</label>
                    <input id="ass-title" type="text" name="title" placeholder="Assignment title" required>

                    <label for="ass-date">Due Date:</label>
                    <input id="ass-date" type="date" name="date" placeholder="Due Date" required>

                    <input type="submit" value="Submit Assignment" class="submit-button">
                </form>
            </div>
        </section>
        <section class="container">
            <h2>Scheduled Assignments</h2>
            <table class="assignments">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th width="40%">Assignment Title</th>
                        <th>Due Date</th>
                        <th width="30%">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        if ($assignment_schedule_r->num_rows > 0) {
                            $sn = 1;
                            while ($assignment_schedule = $assignment_schedule_r->fetch_assoc()) {
                                $id = $assignment_schedule['id'];
                                $title = $assignment_schedule['title'];
                                $filename = $assignment_schedule['filename'];
                                $ends_at = strtotime($assignment_schedule['ends_at']);
                    ?>
                                <tr>
                                    <td><?= $sn++; ?></td>
                                    <td><?= ucwords($title); ?></td>
                                    <td><?= date('jS M, Y', $ends_at); ?></td>
                                    <td>
                                        <a target="_blank" class="submit-button" href="../resources/assignments/<?= $filename; ?>">
                                            View Assign
                                        </a>
                                        <a class="submit-button mxy" href="assignments.php?id=<?= $id; ?>&action=end">
                                            End Submission
                                        </a>
                                    </td>
                                </tr>
                    <?php
                            }
                        } else {
                    ?>
                            <h4>No New Assignments</h4>
                    <?php
                        }
                    ?>
                </tbody>
            </table>
        </section>
        <section class="container">
            <h2>Assignment Submissions</h2>
            <table class="assignments">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th width="30%">Student Name</th>
                        <th width="30%">Assignment Title</th>
                        <th width="30%">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        if ($assignment_submission_r->num_rows > 0) {
                            $sn = 1;
                            while ($assignment_submission = $assignment_submission_r->fetch_assoc()) {
                                $id = $assignment_submission['id'];
                                $title = $assignment_submission['title'];
                                $fname = $assignment_submission['fname'];
                                $lname = $assignment_submission['lname'];
                                $filename = $assignment_submission['filename'];
                                $name = ucwords("$fname $lname");
                    ?>
                                <tr>
                                    <td><?= $sn++; ?></td>
                                    <td><?= ucwords($name); ?></td>
                                    <td>
                                        <a style="text-decoration: underline;" target="_blank" href="../resources/assignment_submissions/<?= $filename; ?>">
                                            <?= ucwords($title); ?>
                                        </a>
                                    </td>
                                    <td style="padding: 5px 0;">
                                        <form method="post">
                                            <input type="hidden" name="action" value="grade">
                                            <input type="hidden" name="id" value="<?= $id; ?>">
                                            <input type="number" min="0" max="100" name="grade" placeholder="enter score" class="mxy" style="width: 100px;">
                                            <button class="submit-button">Grade Assignment</button>
                                        </form>
                                    </td>
                                </tr>
                    <?php
                            }
                        } else {
                    ?>
                            <h4>No New Assignments</h4>
                    <?php
                        }
                    ?>
                </tbody>
            </table>
        </section>
    </main>
    <footer>
        <p>&copy; 2023 MAAUN CS E-Learning System. All rights reserved.</p>
    </footer>
</body>
</html>
