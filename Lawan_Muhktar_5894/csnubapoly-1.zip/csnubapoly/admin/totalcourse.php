<?php
include 'config.php';

// Get the total number of courses
$totalCourses = getTotalCourses();

if ($totalCourses !== false) {
    echo "Total Courses: " . $totalCourses;
} else {
    echo "Failed to retrieve total courses.";
}
?>
