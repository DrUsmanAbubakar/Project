<?php

session_start();

include_once '../connection.php';


if ( !isset($_SESSION['loggedInAdmin']) ) {
	header('location: ../login_admin.php');exit;
}

$sql = "SELECT * FROM `student`";
$students_r = $dbc->query( $sql );

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Nubapoly CS E-Learning System - Students</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
</head>
<body>
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
			<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="students.php">Students</a></li>
            <li><a href="co_list.php">List of Carry Over</a></li>
            <li><a href="carry_over.php">Add Carry Over </a></li>
            <li><a href="carry_over.php">View Grades </a></li>
			<li><a href="resources.php">Resources</a></li>
			<li><a href="assignments.php">Assignments</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
	<main>
        <h2>Students</h2>
        <table>
            <thead>
                <tr>
                    <th>S/N</th>
                    <th>Reg No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>Level</th>
                  
                </tr>
            </thead>
            <tbody>
                <?php
                    // Your PHP code to fetch student data goes here
                    $sn = 1;
                    while ($student = $students_r->fetch_assoc()) {
                        $name = ucwords($student['fname'] . ' ' . $student['lname']);
                        $email = strtolower($student['email']);
                        $department = ucfirst($student['department']);
                        $level = ucwords($student['level']);
                       
                        $stdReg = $student['std_reg'];
                        ?>
                        <tr>
                            <td><?= $sn++; ?></td>
                            <td><?= $stdReg; ?></td>
                            <td><?= $name; ?></td>
                            <td><?= $email; ?></td>
                            <td><?= $department; ?></td>
                            <td><?= $level; ?></td>
                         
                            

                        </tr>
                    <?php
                    }
                ?>
            </tbody>
        </table>
        <div class="filter">
            <label for="department-filter">Filter by department:</label>
            <select id="department-filter">
                <option value="">All</option>
                <option value="Information Technology">Information Technology</option>
                <option value="Cyber Security">Cyber Security</option>
                <option value="Software Engineering">Software Engineering</option>
            </select>
        </div>
    </main>
    <footer>
        <p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
        $('.co-button').click(function() {
        const studentID = $(this).data('student-id');
        const coStatus = $(this).data('co-status');

        // Send an AJAX request to update the CO status
        $.ajax({
            type: 'POST',
            url: 'ajax_co.php', // Create this PHP file
            data: {
                student_id: studentID,
                co_status: coStatus
            },
            success: function(response) {
                 // Handle the response
                 if (response === 'Success') {
                    // Display a success alert
                    alert('CO status updated successfully.');
                } else {
                    // Display an error alert
                    alert('An error occurred while updating CO status.');
                }
            },
            error: function(xhr, status, error) {
                // Handle errors here
                console.error(error);
            }
        });
    });
});


        // Filter students by department
        const departmentFilter = document.getElementById('department-filter');
        const rows = document.querySelectorAll('tbody tr');

        departmentFilter.addEventListener('change', function () {
            const selectedDepartment = departmentFilter.value;

            for (let row of rows) {
                const departmentCell = row.querySelector('td:nth-child(4)').textContent; // Extract the department cell value

                if (selectedDepartment === '' || selectedDepartment === departmentCell) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    </script>
</body>
</html>