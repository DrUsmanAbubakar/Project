<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>MAAUN IT E-Learning System - Admin Logout</title>
	<style>
		body {
			background-color: #f2f2f2;
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
		}

		.container {
			width: 400px;
			margin: 100px auto;
			background-color: #fff;
			padding: 20px;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		}

		h1 {
			text-align: center;
			margin: 0;
			font-size: 24px;
			font-weight: normal;
			margin-bottom: 20px;
		}

		.logout-button {
			margin-top: 10px;
			padding: 10px 20px;
			font-size: 16px;
			background-color: #333;
			color: #fff;
			border: none;
			border-radius: 5px;
			cursor: pointer;
		}

		.logout-button:hover {
			background-color: #fff;
			color: #333;
		}
	</style>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
</head>
<body>
	<div class="container">
		<h1>Admin Logout</h1>
		<p>Are you sure you want to log out?</p>
		<button class="logout-button" onclick="logout()">Logout</button>
	</div>

	<script>
		function logout() {
			// Perform logout logic and redirect to the login page
			// Example:
			// Clear any stored session data or authentication tokens
			// Redirect to the login page
			window.location.href = "admin-login.html";
		}
	</script>
</body>
</html>