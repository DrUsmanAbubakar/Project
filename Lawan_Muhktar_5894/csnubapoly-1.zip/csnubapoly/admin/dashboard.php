<?php

session_start();

include_once '../connection.php';


if ( !isset($_SESSION['loggedInAdmin']) ) {
	header('location: ../login_admin.php');exit;
}

$course_sql = "SELECT COUNT(*) AS `count` FROM `courses`";
$course_r = $dbc->query( $course_sql );
$course_count = $course_r->fetch_assoc()['count'];

$student_sql = "SELECT COUNT(*) AS `count` FROM `student`";
$student_r = $dbc->query( $student_sql );
$student_count = $student_r->fetch_assoc()['count'];

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Nupoly CS E-Learning System - Admin Dashboard</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
</head>
<body>
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
		<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="students.php">Students</a></li>
			<li><a href="instructors/index.php">instructors</a></li>
            <li><a href="co_list.php">List of Carry Over</a></li>
            <li><a href="carry_over.php">Add Carry Over </a></li>
			<li><a href="grades.php">View Grades </a></li>
			<li><a href="resources.php">Resources</a></li>
			<li><a href="assignments.php">Assignments</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
	<main>
		<div class="dashboard">
			<div class="dashboard-item">
				<h2>Total Courses</h2>
				<p><?= $course_count; ?></p>
			<a href="courses.php">View Details</a>
			</div>
			<div class="dashboard-item">
				<h2>Total Students</h2>
				<p><?= $student_count; ?></p>
				<a href="students.php">View Details</a>
			</div>
			
		</div>
	</main>
	<footer>
		<p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved.</p>
	</footer>
</body>
</html>