<?php
include_once '../connection.php';

// Verify if the user is logged in, and if not, redirect to the login page
session_start();
if (!isset($_SESSION['loggedInAdmin'])) {
    header('location: ../login_admin.php');
    exit;
}

// Fetch submission data along with schedule title and student name
$sql = "SELECT s.id AS submission_id, s.grade, s.student_id, s.scheduled_assignment_id, s.submission_date, s.comments, s.filename, 
               a.title AS schedule_title, CONCAT(st.fname, ' ', st.lname) AS student_name
        FROM assignment_submission s
        JOIN assignment_schedule a ON s.scheduled_assignment_id = a.id
        JOIN student st ON s.student_id = st.id";

$result = $dbc->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Nubapoly CS E-Learning System - Assignment Submissions</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
</head>
<body>
    <header>
        <img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
        <h1>NUBAPOLY CS E-Learning System</h1>
    </header>
    <nav>
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="students.php">Students</a></li>
            <li><a href="co_list.php">List of Carry Over</a></li>
            <li><a href="add_material.php">Add Material</a></li>
            <li><a href="grades.php">View Grades </a></li>
            <li><a href="resources.php">Resources</a></li>
            <li><a href="assignments.php">Assignments</a></li>
            <li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <h2>Assignment Submissions</h2>
        <table>
            <thead>
                <tr>
                    <th>S/N</th>
                    <th>Submission ID</th>
                    <th>Grade</th>
                    <th>Student ID</th>
                    <th>Scheduled Assignment ID</th>
                    <th>Submission Date</th>
                    <th>Comments</th>
                    <th>Filename</th>
                
                </tr>
            </thead>
            <tbody>
                <?php
                $sn = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $sn++ . "</td>";
                    echo "<td>" . $row['submission_id'] . "</td>";
                    echo "<td>" . $row['grade'] . "</td>";
                    echo "<td>" . $row['student_name'] . "</td>";
                    echo "<td>" . $row['schedule_title'] . "</td>";
                    echo "<td>" . $row['submission_date'] . "</td>";
                    echo "<td>" . $row['comments'] . "</td>";
                    $filename = $row['filename'];

                    echo '<td><a href="' . $filename . '" target="_blank">' . $filename . '</a></td>';
                                        echo "</tr>";
                                    
                    
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </main>
    <footer>
        <p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved</p>
    </footer>
</body>
</html>
