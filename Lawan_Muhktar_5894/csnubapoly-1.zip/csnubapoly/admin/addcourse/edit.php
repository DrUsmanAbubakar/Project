<?php
include 'config.php'; // Include your database connection configuration

function getCourseById($id)
{
    global $dbc;
    $query = "SELECT * FROM courses WHERE id=$id";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Query failed: " . mysqli_error($dbc));
        return false;
    }

    return mysqli_fetch_assoc($result);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $course = getCourseById($id);
    if (!$course) {
        showError("Course not found!");
    }
} else {
    showError("Invalid request!");
    exit;
}

if (isset($_POST['update_course'])) {
    $course_code = $_POST['course_code'];
    $course_title = $_POST['course_title'];
    $instructor_id = $_POST['instructor'];
    $credit_hours = $_POST['credit_hours'];

    if (updateCourse($id, $course_code, $course_title, $instructor_id, $credit_hours)) {
        echo "<p>Course updated successfully!</p>";
        $course = getCourseById($id); // Refresh course data after update
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course</title>
</head>

<body>
    <h1>Edit Course</h1>

    <form action="" method="post">
        <label for="course_code">Course Code:</label>
        <input type="text" name="course_code" value="<?php echo $course['course_code']; ?>" required>
        <label for="course_title">Course Title:</label>
        <input type="text" name="course_title" value="<?php echo $course['course_title']; ?>" required>

        <!-- Fetch Instructors from Database -->
        <label for="instructor">Instructor:</label>
        <select name="instructor" required>
            <?php
            $instructorsResult = getInstructors();
            if ($instructorsResult) {
                while ($instructor = mysqli_fetch_assoc($instructorsResult)) {
                    $selected = ($instructor['id'] == $course['instructor_id']) ? 'selected' : '';
                    echo "<option value='{$instructor['id']}' $selected>{$instructor['name']}</option>";
                }
            }
            ?>
        </select>

        <label for="credit_hours">Credit Hours:</label>
        <input type="number" name="credit_hours" value="<?php echo $course['credit_hours']; ?>" required>
        <button type="submit" name="update_course">Update Course</button>
    </form>
</body>

</html>
