<?php
include 'config.php'; // Include your database connection configuration

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    if (isset($_POST['confirm_delete'])) {
        if (deleteCourse($id)) {
            echo "<p>Course deleted successfully!</p>";
            echo "<a href='index.php'>Back to Course List</a>";
            exit;
        }
    }
} else {
    showError("Invalid request!");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Course</title>
</head>

<body>
    <h1>Delete Course</h1>

    <p>Are you sure you want to delete this course?</p>
    <form action="" method="post">
        <button type="submit" name="confirm_delete">Yes, Delete</button>
    </form>

    <a href="index.php">Back to Course List</a>
</body>

</html>
