<?php

$host = 'localhost';
$dbname = 'csdept';
$username = 'root';
$password = '';

$dbc = new mysqli($host, $username, $password, $dbname) or die("Connection Error: " . mysqli_connect_error());

function showError($message)
{
    echo "<p style='color: red;'>Error: $message</p>";
}

function getInstructors()
{
    global $dbc;
    $query = "SELECT * FROM instructors";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Query failed: " . mysqli_error($dbc));
        return false;
    }

    return $result;
}

function getCourses()
{
    global $dbc;
    $query = "SELECT courses.*, instructors.name AS instructor_name FROM courses
              LEFT JOIN instructors ON courses.instructor_id = instructors.id";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Query failed: " . mysqli_error($dbc));
        return false;
    }

    return $result;
}

function addCourse($course_code, $course_title, $instructor_id, $credit_hours)
{
    global $dbc;
    $query = "INSERT INTO courses (course_code, course_title, instructor_id, credit_hours) 
              VALUES ('$course_code', '$course_title', $instructor_id, $credit_hours)";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Insert failed: " . mysqli_error($dbc));
        return false;
    }

    return true;
}

function updateCourse($id, $course_code, $course_title, $instructor_id, $credit_hours)
{
    global $dbc;
    $query = "UPDATE courses 
              SET course_code='$course_code', course_title='$course_title', 
                  instructor_id=$instructor_id, credit_hours=$credit_hours 
              WHERE id=$id";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Update failed: " . mysqli_error($dbc));
        return false;
    }

    return true;
}

function deleteCourse($id)
{
    global $dbc;
    $query = "DELETE FROM courses WHERE id=$id";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Delete failed: " . mysqli_error($dbc));
        return false;
    }

    return true;
}
?>
