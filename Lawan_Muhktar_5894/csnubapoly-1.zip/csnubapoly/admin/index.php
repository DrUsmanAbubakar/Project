<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Page</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">
    <style>
        .add-form {
            display: none;
        }
    </style>
</head>

<body>
    <h1>Course Management</h1>

    <!-- Add Course Toggle Button -->
    <button id="toggleAddForm">Add Course</button>

    <!-- Add Course Form -->
    <form id="addForm" class="add-form" action="" method="post">
        <label for="course_code">Course Code:</label>
        <input type="text" name="course_code" required>
        <label for="course_title">Course Title:</label>
        <input type="text" name="course_title" required>

        <!-- Fetch Instructors from Database -->
        <label for="instructor">Instructor:</label>
        <select name="instructor" required>
            <?php
            include 'config.php'; // Include your database connection configuration
            $instructorsResult = getInstructors();
            if ($instructorsResult) {
                while ($instructor = mysqli_fetch_assoc($instructorsResult)) {
                    echo "<option value='{$instructor['id']}'>{$instructor['name']}</option>";
                }
            }
            ?>
        </select>

        <label for="credit_hours">Credit Hours:</label>
        <input type="number" name="credit_hours" required>
        <button type="submit" name="add_course">Add Course</button>
    </form>

    <?php
    // Add Course
    if (isset($_POST['add_course'])) {
        $course_code = $_POST['course_code'];
        $course_title = $_POST['course_title'];
        $instructor_id = $_POST['instructor'];
        $credit_hours = $_POST['credit_hours'];

        if (addCourse($course_code, $course_title, $instructor_id, $credit_hours)) {
            echo "<p>Course added successfully!</p>";
        }
    }
    ?>

    <!-- Courses Table -->
    <table id="courses_table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Course Code</th>
                <th>Course Title</th>
                <th>Instructor</th>
                <th>Credit Hours</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $result = getCourses();
            if ($result) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>{$row['id']}</td>";
                    echo "<td>{$row['course_code']}</td>";
                    echo "<td>{$row['course_title']}</td>";
                    echo "<td>{$row['instructor_name']}</td>";
                    echo "<td>{$row['credit_hours']}</td>";
                    echo "<td><a href='edit.php?id={$row['id']}'>Edit</a> | <a href='delete.php?id={$row['id']}'>Delete</a></td>";
                    echo "</tr>";
                }
            }
            ?>
        </tbody>
    </table>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
    <script>
        $(document).ready(function () {
            $('#courses_table').DataTable();

            // Toggle Add Course Form
            $('#toggleAddForm').on('click', function () {
                $('#addForm').toggle();
            });
        });
    </script>
</body>

</html>
