<?php

session_start();

include_once '../../connection.php';


if (!isset($_SESSION['loggedInAdmin'])) {
    header('location: ../../login_admin.php');
    exit;
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Nupoly CS E-Learning System - Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="../../assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/dashboard.css">
    <link rel="stylesheet" type="text/css" href="../../css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../js/bootstrap.js">
    <link rel="stylesheet" type="text/css" href="../../js/bootstrap.min.js">
</head>

<body>
    <header>
        <img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
        <h1>NUBAPOLY CS E-Learning System</h1>
    </header>
    <nav>
        <ul>
            <li><a href="../dashboard.php">Home</a></li>
            <li><a href="../courses.php">Courses</a></li>

            <li><a href="../students.php">Students</a></li>
            <li><a href="index.php">instructors</a></li>

            <li><a href="../co_list.php">List of Carry Over</a></li>
            <li><a href="../carry_over.php">Add Carry Over </a></li>
            <li><a href="../grades.php">View Grades </a></li>
            <li><a href="../resources.php">Resources</a></li>
            <li><a href="../assignments.php">Assignments</a></li>
            <li style="float:right"><a class="active" href="../../logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <?php
        $host = 'localhost';
        $dbname = 'csdept';
        $username = 'root';
        $password = '';

        $dbc = mysqli_connect($host, $username, $password, $dbname) or die("Connection Error: " . mysqli_connect_error());

        // Function to show error messages
        function showError($message)
        {
            echo "<div class='alert alert-danger mt-3' role='alert'>
            <strong>Error:</strong> $message
          </div>";
        }

        // Function to show success messages
        function showSuccess($message)
        {
            echo "<div class='alert alert-success mt-3' role='alert'>
            <strong>Success:</strong> $message
          </div>";
        }

        // Function to get instructors
        function getInstructors()
        {
            global $dbc;
            $query = "SELECT * FROM instructors";
            $result = mysqli_query($dbc, $query);

            if (!$result) {
                showError("Query failed: " . mysqli_error($dbc));
                return false;
            }

            return $result;
        }

        // Function to add instructor
        function addInstructor($name, $department, $number)
        {
            global $dbc;
            $name = mysqli_real_escape_string($dbc, $name);
            $department = mysqli_real_escape_string($dbc, $department);
            $number = mysqli_real_escape_string($dbc, $number);

            $query = "INSERT INTO instructors (name, department, number) VALUES ('$name', '$department', '$number')";
            $result = mysqli_query($dbc, $query);

            if (!$result) {
                showError("Insert failed: " . mysqli_error($dbc));
                return false;
            }

            // showSuccess("Instructor added successfully!");
            return true;
        }

        ?>

        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Instructor Management</title>
            <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

        </head>
        <style>
            #add-form {
                display: none;
            }
        </style>

        <body>
            <div class="cotainer">
                <button id="toggleAddForm">Add Instructor</button>

                <h1 class="mt-3">Instructor Management</h1>

                <!-- Add Instructor Form -->
                <form action="" method="post" id="add-form">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="department">Department:</label>
                        <input type="text" name="department" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="number">Number:</label>
                        <input type="text" name="number" class="form-control" required>
                    </div>
                    <button type="submit" name="add_instructor" class="btn btn-primary mt-2">Add Instructor</button>
                </form>

                <?php
                // Add Instructor
                if (isset($_POST['add_instructor'])) {
                    $name = $_POST['name'];
                    $department = $_POST['department'];
                    $number = $_POST['number'];

                    addInstructor($name, $department, $number);
                }
                ?>

                <!-- Error/Success Alerts -->
                <?php
                if (isset($_POST['add_instructor'])) {
                    if (addInstructor($name, $department, $number)) {
                        showSuccess("Instructor added successfully!");
                    } else {
                        showError("Failed to add instructor. Please check the form and try again.");
                    }
                }
                ?>

                <!-- Instructors Table -->
                <table id="instructors_table" class="table mt-3">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Department</th>
                            <th>Number</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = getInstructors();
                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>{$row['id']}</td>";
                                echo "<td>{$row['name']}</td>";
                                echo "<td>{$row['department']}</td>";
                                echo "<td>{$row['number']}</td>";
                                echo "<td><a href='edit.php?id={$row['id']}' class='btn btn-primary btn-sm'>Edit</a> | <a href='delete.php?id={$row['id']}' class='btn btn-danger btn-sm'>Delete</a></td>";
                                echo "</tr>";
                            }
                        }
                        ?>
                    </tbody>
                </table>

                <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
                <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
                <script>
                    $(document).ready(function() {
                        $('#instructors_table').DataTable();
                    });
                </script>
            </div>

            <!-- Bootstrap JS -->
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
            <script>
                $(document).ready(function() {
                    $('#courses_table').DataTable();

                    // Toggle Add Course Form
                    $('#toggleAddForm').on('click', function() {
                        $('#add-form').toggle();
                    });
                });
            </script>
        </body>

        </html>
    </main>
    <footer>
        <p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved.</p>
    </footer>
</body>

</html>