<?php
include 'config.php'; // Include your database connection configuration

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    if (isset($_POST['confirm_delete'])) {
        if (deleteInstructor($id)) {
            echo "<p>Instructor deleted successfully!</p>";
            echo "<a href='index.php'>Back to Instructor List</a>";
            exit;
        }
    }
} else {
    showError("Invalid request!");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Instructor</title>
</head>

<body>
    <h1>Delete Instructor</h1>

    <div class="container">
        <h1 class="mt-3">Delete Instructor</h1>

        <p>Are you sure you want to delete this instructor?</p>
        <form action="" method="post">
            <button type="submit" name="confirm_delete" class="btn btn-danger">Yes, Delete</button>
        </form>

        <a href="index.php" class="btn btn-secondary mt-2">Back to Instructor List</a>
    </div>

</body>

</html>
