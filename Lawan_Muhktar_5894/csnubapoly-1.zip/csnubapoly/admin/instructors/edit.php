<?php
include 'config.php'; // Include your database connection configuration

function getInstructorById($id)
{
    global $dbc;
    $query = "SELECT * FROM instructors WHERE id=$id";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Query failed: " . mysqli_error($dbc));
        return false;
    }

    return mysqli_fetch_assoc($result);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $instructor = getInstructorById($id);
    if (!$instructor) {
        showError("Instructor not found!");
    }
} else {
    showError("Invalid request!");
    exit;
}

if (isset($_POST['update_instructor'])) {
    $name = $_POST['name'];
    $department = $_POST['department'];
    $number = $_POST['number'];

    if (updateInstructor($id, $name, $department, $number)) {
      //  showSuccess("Instructor updated successfully!");
        $instructor = getInstructorById($id); // Refresh instructor data after update
    } else {
        showError("Failed to update instructor. Please check the form and try again.");
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Instructor</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h1 class="mt-3">Edit Instructor</h1>

        <!-- Error/Success Alerts -->
        <?php
        if (isset($_POST['update_instructor'])) {
            if (updateInstructor($id, $name, $department, $number)) {
                showSuccess("Instructor updated successfully!");
            } else {
              //  showError("Failed to update instructor. Please check the form and try again.");
            }
        }
        ?>

        <form action="" method="post">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" name="name" value="<?php echo $instructor['name']; ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="department">Department:</label>
                <input type="text" name="department" value="<?php echo $instructor['department']; ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="number">Number:</label>
                <input type="text" name="number" value="<?php echo $instructor['number']; ?>" class="form-control" required>
            </div>
            <button type="submit" name="update_instructor" class="btn btn-success mt-2">Update Instructor</button>
            <a href="index.php" class="btn btn-primary mt-2"><- Back</a>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
