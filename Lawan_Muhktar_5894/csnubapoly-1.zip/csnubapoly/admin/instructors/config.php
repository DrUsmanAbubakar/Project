<?php
$host = 'localhost';
$dbname = 'csdept';
$username = 'root';
$password = '';

$dbc = mysqli_connect($host, $username, $password, $dbname) or die("Connection Error: " . mysqli_connect_error());

function showError($message)
{
    echo "<div class='alert alert-danger mt-3' role='alert'>
            <strong>Error:</strong> $message
          </div>";
}

function showSuccess($message)
{
    echo "<div class='alert alert-success mt-3' role='alert'>
            <strong>Success:</strong> $message
          </div>";
}

function getInstructors()
{
    global $dbc;
    $query = "SELECT * FROM instructors";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Query failed: " . mysqli_error($dbc));
        return false;
    }

    return $result;
}

function addInstructor($name, $department, $number)
{
    global $dbc;
    $name = mysqli_real_escape_string($dbc, $name);
    $department = mysqli_real_escape_string($dbc, $department);
    $number = mysqli_real_escape_string($dbc, $number);

    $query = "INSERT INTO instructors (name, department, number) VALUES ('$name', '$department', '$number')";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Insert failed: " . mysqli_error($dbc));
        return false;
    }

    showSuccess("Instructor added successfully!");
    return true;
}

function updateInstructor($id, $name, $department, $number)
{
    global $dbc;
    $name = mysqli_real_escape_string($dbc, $name);
    $department = mysqli_real_escape_string($dbc, $department);
    $number = mysqli_real_escape_string($dbc, $number);

    $query = "UPDATE instructors SET name='$name', department='$department', number='$number' WHERE id=$id";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Update failed: " . mysqli_error($dbc));
        return false;
    }

   // showSuccess("Instructor updated successfully!");
    return true;
}

function deleteInstructor($id)
{
    global $dbc;
    $query = "DELETE FROM instructors WHERE id=$id";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Delete failed: " . mysqli_error($dbc));
        return false;
    }

    showSuccess("Instructor deleted successfully!");
    return true;
}
?>
