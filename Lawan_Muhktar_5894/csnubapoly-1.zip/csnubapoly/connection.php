<?php 
	$dbc = new mysqli('localhost','root','','csdept') or die("Connection Error: " . mysqli_connect_error());
