<?php

session_start();

include_once '../connection.php';


if ( !isset($_SESSION['loggedInUser']) ) {
	header('location: ../login.php');exit;
}


if ( !isset($_GET['id']) or !is_numeric($_GET['id']) or !isset($_GET['title']) ) {

	header('location: assignments.php');exit;

}

$id = $dbc->real_escape_string( $_GET['id'] );
$title = $dbc->real_escape_string( $_GET['title'] );

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>NUBAPOLY CS E-Learning System - Assignment</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
</head>
<body>
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
	<ul>
			<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="assignments.php">Assignments</a></li>
            <li><a href="course_reg.php">Course Form</a></li>
			<li><a href="resources.php">Resources</a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
	<main>
		<div class="form-container">
			<h2>Assignment Submission</h2>
			<h3><?= ucwords($title); ?></h3>

			<form id="assignmentForm" action="assignment_script.php" method="post" enctype="multipart/form-data">
				<input type="hidden" name="action" value="upload_assignment">
				<input type="hidden" name="id" value="<?= $id; ?>">
				<input type="hidden" name="title" value="<?= $title; ?>">

				<label for="assignmentFile">Upload File:</label>
				<input type="file" id="assignmentFile" name="assignment" required>

				<label for="submissionComments">Comments:</label>
				<textarea id="submissionComments" name="comments" rows="4"></textarea>

				<input type="submit" name="submit" value="Submit" class="submit-button">
			</form>
		</div>
	</main>
	<footer>
		<p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved.</p>
	</footer>
</body>
</html>