<?php

session_start();

include_once '../connection.php';


if ( !isset($_SESSION['loggedInUser']) ) {
	header('location: ../login.php');exit;
}

$student_id = $_SESSION['student_id'];

$course_sql = "SELECT COUNT(*) AS `count` FROM `course_reg` WHERE `student_id`='$student_id'";
$course_r = $dbc->query( $course_sql );
$course_count = $course_r->fetch_assoc()['count'];

$grade_sql = "SELECT AVG(`grade`) AS `grade` FROM `assignment_submission`
WHERE `student_id`='$student_id'";
$grade_r = $dbc->query( $grade_sql );
$grade = $grade_r->fetch_assoc();
$avg_grade = isset($grade['grade'])?$grade['grade']:0;

$assignment_sql = "SELECT COUNT(*) AS `count`
FROM `assignment_schedule` `as`
WHERE `as`.`id` NOT IN
(SELECT DISTINCT `scheduled_assignment_id`
FROM `assignment_submission`
WHERE `student_id`='$student_id') AND `status`='1'";
$assignment_r = $dbc->query( $assignment_sql );
$assignment_count = $assignment_r->fetch_assoc()['count'];

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>NUBAPOLY CS E-Learning System - Student Portal</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
</head>
<body>
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
			<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="assignments.php">Assignments</a></li>
			<li><a href="grades.php">View Grades</a></li>
			<li><a href="resources.php">Resources</a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
	<main>
		<div class="dashboard">
			<div class="dashboard-item">
				<h2>My Courses</h2>
				<p><?= $course_count; ?></p>
				<a href="courses.php">View Courses</a>
			</div>
			<div class="dashboard-item">
				<h2>Assignments Due</h2>
				<p><?= $assignment_count; ?></p>
				<a href="assignments.php">View Assignments</a>
			</div>
			<div class="dashboard-item">
				<h2>Grades</h2>
				<p><?= sprintf('%.2f', $avg_grade); ?></p>
				<a href="grades.php">View Grades</a>
			</div>
		</div>
	</main>
	<footer>
	<p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved.</p>
	</footer>
</body>
</html>