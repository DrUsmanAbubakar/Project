<?php

include_once '../connection.php';





?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>NUBAPOLY CS E-Learning System - Courses</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
    <link rel="stylesheet" type="text css" href="../js/bootstrap.min.js">
    <style>
        .co-yes {
            color: red;
        }

        .co-no {
            color: green;
        }
    </style>
</head>
<body>
    <header>
        <img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
        <h1>NUBAPOLY CS E-Learning System</h1>
    </header>
    <nav>
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="assignments.php">Assignments</a></li>
            <li><a href="grades.php">View Grades</a></li>
            <li><a href="course_reg.php">Course Form</a></li>
            <li><a href="resources.php">Resources</a></li>
            <li><a href="contact.php">Contact Us</a></li>
            <li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
    <?php include "course_reg.php";
       ?>
    </main>
    <footer>
        <p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved.</p>
    </footer>
</body>
</html>
