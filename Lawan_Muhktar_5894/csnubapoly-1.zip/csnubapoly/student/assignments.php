<?php

session_start();

include_once '../connection.php';


if ( !isset($_SESSION['loggedInUser']) ) {
	header('location: ../login.php');exit;
}

$student_id = $_SESSION['student_id'];

$sql = "SELECT DISTINCT `as`.`id`,`ends_at`,`title`,`filename`
FROM `assignment_schedule` `as`
WHERE `as`.`id` NOT IN
(SELECT DISTINCT `scheduled_assignment_id`
FROM `assignment_submission`
WHERE `student_id`='$student_id') AND `status`='1'";
$scheduled_assignment_r = $dbc->query( $sql );

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>NUBAPOLY CS E-Learning System - Assignment Submission</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
</head>
<body>
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
			<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="assignments.php">Assignments</a></li>
			<li><a href="grades.php">View Grades</a></li>
			<li><a href="resources.php">Resources</a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
	<main>
		<div class="form-container" style="width: unset;">
			<h2>Scheduled Assignments</h2>
			<table class="assignments">
				<thead>
					<tr>
						<th>S/N</th>
						<th width="40%">Assignment Title</th>
						<th>Due Date</th>
						<th width="30%">Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
						if( $scheduled_assignment_r->num_rows > 0){
							$sn = 1;
							while ( $scheduled_assignment = $scheduled_assignment_r->fetch_assoc() ) {
								$id = $scheduled_assignment['id'];
								$title = $scheduled_assignment['title'];
								$filename = $scheduled_assignment['filename'];
								$ends_at = strtotime($scheduled_assignment['ends_at']);
								?>
								<tr>
									<td><?= $sn++;?></td>
									<td><?= ucwords($title);?></td>
									<td><?= date('jS M, Y', $ends_at);?></td>
									<td>
										<a target="_blank" class="submit-button" href="../resources/assignments/<?=$filename;?>">
											Download Assign
										</a>
									<a class="submit-button mxy" href="assignment.php?id=<?=$id;?>&title=<?=$title;?>">
											Submit Assign
										</a>
									</td>
								</tr>
								<?php
							}
						}else{
							?>
							<h4>No New Assignments</h4>
							<?php 
						}
					?>
				</tbody>
			</table>
		</div>
	</main>
	<footer>
		<p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved.</p>
	</footer>
</body>
</html>