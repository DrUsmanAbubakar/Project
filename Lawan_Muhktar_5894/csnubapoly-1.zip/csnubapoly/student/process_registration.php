<?php

include 'config.php';

if (isset($_POST['register_course'])) {
    $student_id = $_POST['student_id'];
    $course_id = $_POST['course'];

    if (isAlreadyRegistered($student_id, $course_id)) {
        header("Location: courses.php?success=false");
            exit();
    } else {
        if (registerCourse($student_id, $course_id)) {
            // Registration successful, redirect with success parameter
            header("Location: courses.php?success=true");
            exit();
        } else {
            echo "Course registration failed.";
        }
    }
}
?>
