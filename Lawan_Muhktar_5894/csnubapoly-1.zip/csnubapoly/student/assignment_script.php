<?php
session_start();

include_once '../connection.php';

if (!isset($_SESSION['loggedInUser'])) {
    header('location: ../login.php');
    exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'upload_assignment') {
    $user_id = $_SESSION['student_id'];
    $username = $_SESSION['loggedInUser']['username'];
    $id = $dbc->real_escape_string($_POST['id']);
    $title = $dbc->real_escape_string($_POST['title']);
    $comments = $dbc->real_escape_string($_POST['comments']);
    $assignment = $_FILES['assignment'];
    $save_path = '../resources/assignment_submissions';

    // Ensure 'student_id' exists in the student table
    $sql_check_student = "SELECT id FROM student WHERE id = '$user_id'";
    $result = $dbc->query($sql_check_student);

    if ($result && $result->num_rows > 0) {
        $name_arr = explode('.', $assignment['name']);
        $new_filename = "${username}_${title}_" . date('Y-m-d_H-i') . '.' . end($name_arr);
        $new_filename = str_replace(' ', '-', $new_filename);

        $save_file = move_uploaded_file($assignment['tmp_name'], "$save_path/$new_filename");

        if ($save_file) {
            $sql = "INSERT INTO `assignment_submission` (`student_id`, `scheduled_assignment_id`, `submission_date`, `comments`, `filename`, `status`)
                VALUES ('$user_id', '$id', CURRENT_TIMESTAMP(), '$comments', '$new_filename', 'Pending')";

            try {
                $assignment_submission_r = $dbc->query($sql);
            } catch (Exception $e) {
                $msg = $e->getMessage();
            }

            header('location: assignments.php');
            exit;
        } else {
            echo "Error: Failed to save the assignment file.";
        }
    } else {
        echo "Error: Invalid student ID.";
    }
}
?>
