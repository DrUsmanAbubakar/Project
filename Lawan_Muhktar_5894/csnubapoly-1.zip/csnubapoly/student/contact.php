<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>NUBAPOLY CS E-Learning System - Contact</title>
	<style>
		body {
			background-color: green;
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
		}

		.container {
			width: 500px;
			margin: 100px auto;
			padding: 20px;
			background-color: #fff;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		}

		h1 {
			text-align: center;
		}

		input[type="text"],
		input[type="email"],
		textarea {
			width: 100%;
			padding: 10px;
			margin-bottom: 20px;
			border: 1px solid #ccc;
			border-radius: 4px;
			box-sizing: border-box;
		}

		textarea {
			height: 120px;
		}

		button {
			width: 100%;
			padding: 10px;
			background-color: green;
			color: #fff;
			border: none;
			border-radius: 4px;
			cursor: pointer;
		}

		button:hover {
			background-color: #555;
		}
	</style>
	<script>
		function submitForm() {
			// Perform form submission logic here
			// You can use AJAX to send the form data to a server-side script
			// for processing and handling the contact request
			alert("Form submitted successfully!");
			document.getElementById("contact-form").reset();
		}
	</script>
</head>
<body>
	<div class="container">
		<h1>Contact Us</h1>
		<form id="contact-form">
			<input type="text" name="name" placeholder="Your Name" required>
			<input type="email" name="email" placeholder="Your Email" required>
			<textarea name="message" placeholder="Your Message" required></textarea>
			<button type="button" onclick="submitForm()">Submit</button>
		</form>
		<div class="form-toggle">
				Go back to Dashboard <a href="dashboard.php">Dashboard</a>
	</div>
</body>
</html>