<?php

session_start();

include_once '../connection.php';


if ( !isset($_SESSION['loggedInUser']) ) {
	header('location: ../login.php');exit;
}

$studentID = $_SESSION['student_id'];

$sql = "SELECT s.id AS submission_id, s.grade, s.scheduled_assignment_id, s.submission_date, s.comments, s.filename, s.status,
               a.title AS schedule_title
        FROM assignment_submission s
        JOIN assignment_schedule a ON s.scheduled_assignment_id = a.id
        WHERE s.student_id = ?";

// Use prepared statement to prevent SQL injection
$stmt = $dbc->prepare($sql);
$stmt->bind_param("i", $studentID);
$stmt->execute();
$result = $stmt->get_result();
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>NUBAPOLY CS E-Learning System - Assignment Submission</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="../assets/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
</head>
<body>
	<header>
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>NUBAPOLY CS E-Learning System</h1>
	</header>
	<nav>
		<ul>
			<li><a href="dashboard.php">Home</a></li>
			<li><a href="courses.php">Courses</a></li>
			<li><a href="assignments.php">Assignments</a></li>
            <li><a href="grades.php">View Grades</a></li>
        
			<li><a href="resources.php">Resources</a></li>
			<li><a href="contact.php">Contact Us</a></li>
			<li style="float:right"><a class="active" href="../logout.php">Logout</a></li>
		</ul>
	</nav>
	<main>
    <h2>Your Assignment Submissions</h2>
        <table>
            <thead>
                <tr>
                    <th>S/N</th>
                    <th>Submission ID</th>
                    <th>Grade</th>
                    <th>Scheduled Assignment Title</th>
                    <th>Submission Date</th>
                    <th>Comments</th>
                    <th>Filename</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sn = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $sn++ . "</td>";
                    echo "<td>" . $row['submission_id'] . "</td>";
                    echo "<td>" . $row['grade'] . "</td>";
                    echo "<td>" . $row['schedule_title'] . "</td>";
                    echo "<td>" . $row['submission_date'] . "</td>";
                    echo "<td>" . $row['comments'] . "</td>";
                    $filename = $row['filename'];

echo '<td><a href="' . $filename . '" target="_blank">' . $filename . '</a></td>';
echo "<td>" . $row['status'] . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
	</main>
	<footer>
		<p>© 2023 Nuhu Bamalli Polytechnic, Zaria CS E-Learning System. All rights reserved.</p>
	</footer>
</body>
</html>