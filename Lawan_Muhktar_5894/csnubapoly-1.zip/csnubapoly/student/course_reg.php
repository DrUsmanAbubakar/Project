<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Registration</title>
    <!-- Add Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Custom CSS for layout */
        .container {
            margin-top: 50px;
        }

        .registration-form {
            margin-top: 20px;
        }

        .profile-details {
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <!-- Profile Details -->
                <div class="profile-details">
                    <h2>Student Profile</h2>
                    <?php
                    include 'config.php';                    // Fetch and display student details from the student table
                    $studentId = $_SESSION['student_id'];
                    $query = "SELECT * FROM student WHERE id = $studentId";
                    $result = mysqli_query($dbc, $query);

                    if ($result && $row = mysqli_fetch_assoc($result)) {
                        echo "<p>Name: {$row['fname']}</p>";
                        echo "<p>Email: {$row['email']}</p>";
                        // Add more details as needed
                    } else {
                        echo "<p>Error fetching student details.</p>";
                    }
                    ?>
                </div>

                <!-- Registered Courses -->
                <div class="profile-details">
                    <h2>Registered Courses</h2>
                    <?php
                    // Fetch and display registered courses for the student
                    $query = "SELECT courses.course_title FROM courses
                              JOIN course_reg ON courses.id = course_reg.course_id
                              WHERE course_reg.student_id = $studentId";
                    $result = mysqli_query($dbc, $query);

                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<p>{$row['course_title']}</p>";
                        }
                    } else {
                        echo "<p>Error fetching registered courses.</p>";
                    }
                    ?>
                </div>
            </div>

            <div class="col-md-8">
                <!-- Course Registration Form -->
                <form id="registrationForm" class="registration-form" action="process_registration.php" method="post">
                    <h2>Course Registration</h2>
                    <label for="course">Select Course:</label>
                    <select name="course" class="form-control" required>
                        <?php
                        $coursesResult = getCourses();
                        if ($coursesResult) {
                            while ($course = mysqli_fetch_assoc($coursesResult)) {
                                echo "<option value='{$course['id']}'>{$course['course_title']}</option>";
                            }
                        }
                        ?>
                    </select>

                    <!-- Using $_SESSION['student_id'] as user_id -->
                    <input type="hidden" name="student_id" value="<?php echo $_SESSION['student_id']; ?>">

                    <button type="submit" name="register_course" class="btn btn-primary mt-3">Register Course</button>
                </form>

                <!-- Bootstrap Alert for Success Message -->
                <div id="successAlert" class="alert alert-success mt-3" style="display: none;">
                    <strong>Success!</strong> Course registration successful!
                </div>
                <div id="failAlert" class="alert alert-warning mt-3" style="display: none;">
                    <strong>Fai!</strong> You are already registered for this course.
                </div>

            </div>
        </div>
    </div>

    <!-- Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Custom JavaScript to show success alert -->
    <script>
        $(document).ready(function() {
            // Check if URL has a success parameter
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('success') && urlParams.get('success') === 'true') {
                // Show the success alert
                $('#successAlert').show();
            } if (urlParams.has('success') && urlParams.get('success') === 'false') {
                $('#failAlert').show();
            } else {
                
            }
        });
    </script>
</body>

</html>