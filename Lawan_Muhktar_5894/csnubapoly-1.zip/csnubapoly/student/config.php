<?php
session_start();
$host = 'localhost';
$dbname = 'csdept';
$username = 'root';
$password = '';

$dbc = new mysqli($host, $username, $password, $dbname) or die("Connection Error: " . mysqli_connect_error());

function showError($message)
{
    echo "<p style='color: red;'>Error: $message</p>";
}

function getCourses()
{
    global $dbc;
    $query = "SELECT * FROM courses";
    $result = mysqli_query($dbc, $query);

    if (!$result) {
        showError("Query failed: " . mysqli_error($dbc));
        return false;
    }

    return $result;
}

function isAlreadyRegistered($student_id, $course_id)
{
    global $dbc;

    // Prepare the statement
    $query = "SELECT * FROM course_reg WHERE student_id = ? AND course_id = ?";
    $stmt = mysqli_prepare($dbc, $query);

    if (!$stmt) {
        showError("Prepare statement failed: " . mysqli_error($dbc));
        return false;
    }

    // Bind parameters
    mysqli_stmt_bind_param($stmt, "ii", $student_id, $course_id);

    // Execute the statement
    mysqli_stmt_execute($stmt);

    // Get result
    $result = mysqli_stmt_get_result($stmt);

    if (!$result) {
        showError("Query failed: " . mysqli_error($dbc));
        return false;
    }

    // Check if already registered
    $num_rows = mysqli_num_rows($result);

    // Clean up
    mysqli_stmt_close($stmt);

    return $num_rows > 0;
}

function registerCourse($student_id, $course_id)
{
    global $dbc;

    // Prepare the statement
    $query = "INSERT INTO course_reg (student_id, course_id) VALUES (?, ?)";
    $stmt = mysqli_prepare($dbc, $query);

    if (!$stmt) {
        showError("Prepare statement failed: " . mysqli_error($dbc));
        return false;
    }

    // Bind parameters
    mysqli_stmt_bind_param($stmt, "ii", $student_id, $course_id);

    // Execute the statement
    $result = mysqli_stmt_execute($stmt);

    if (!$result) {
        showError("Insert failed: " . mysqli_error($dbc));
        return false;
    }

    // Clean up
    mysqli_stmt_close($stmt);

    return true;
}

?>
