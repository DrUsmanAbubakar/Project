<?php

session_start();

include_once 'connection.php';


if ( isset($_SESSION['loggedInUser']) ) {
	header('location: ./student/dashboard.php');exit;
}
	
if ( isset($_POST['action']) AND $_POST['action'] === 'register' ) {

	$fname = $dbc->real_escape_string( $_POST['fname'] );
	$lname = $dbc->real_escape_string( $_POST['lname'] );
	$username = $dbc->real_escape_string( $_POST['username'] );
	$email = $dbc->real_escape_string( $_POST['email'] );
	$password = $dbc->real_escape_string( $_POST['password'] );

	$sql = "INSERT INTO `student`(`fname`,`lname`,`username`,`email`,`password`)
	VALUES('$fname','$lname','$username','$email','$password')";

	$query = $dbc->query( $sql );

	if ( $dbc->affected_rows > 0 ){
		header('location: login.php');exit;
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Nubapoly CS E-Learning System - Student Login/Register</title>
	<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="assets/css/login_register.css">
</head>
<body>
	<div class="container">
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>Nubapoly CS E-Learning System</h1>
		<div id="register-form" class="register-form">
			<form method="post">
				<input type="hidden" name="action" value="register">
				<input type="text" name="fname" placeholder="First Name">
				<input type="text" name="lname" placeholder="Last Name">
				<input type="text" name="email" placeholder="Email">
				<input type="text" name="username" placeholder="Username">
				<input type="password" name="password" placeholder="Password">
				<button type="submit">Register</button>
			</form>
			<div class="form-toggle">
				Already have an account? <a href="login.php">Login here</a>
			</div>
			<div class="form-toggle">
				Go back to Home Page <a href="index.php">Home Page</a>
		</div>
	</div>
</body>
</html>