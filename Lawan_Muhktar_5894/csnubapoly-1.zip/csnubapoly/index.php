<!DOCTYPE html>
<html>
<head>
	<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
	<h1 style="text-align: center;">Nuhu Bamalli Polytechnic, Zaria</h1>

	<title>E-Learning System</title>
	<link rel="stylesheet" type="text/css" href="./assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="../js/bootstrap.min.js">
</head>
<body>
	<header>
		<nav class="navbar">
			<div class="admin-s">
				<a href="login_admin.php">Admin Login</a>
			</div>
			<div class="user-s">
				<a href="register.php">Register</a>
				<a href="login.php">Login</a>
			</div>
		</nav>
	</header>
	<section class="my-5">
		<h1 class="text-center text-uppercase py-5">Welcome to</h1>
	</section>
	<main class="my-5 py-5">
		<section class="content">
			<h1>Computer Science E-Learning System</h1>
		</section>
	</main>
	<footer>
		<h5 style="text-align: center;">&copy;2023 Nuhu Bamalli Polytechnic, Zaria. All rights reserved.</h5>
		</footer>
</body>
</html>