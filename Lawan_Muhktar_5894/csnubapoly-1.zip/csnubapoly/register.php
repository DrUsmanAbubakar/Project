<?php
session_start();

include_once 'connection.php';

if (isset($_SESSION['loggedInUser'])) {
	header('location: ./student/dashboard.php');
	exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'register') {

	function generateStudentRegistrationNumber()
	{
		// Define the year part of the registration number
		$year = date('Y'); // Assuming the academic year is the current year

		// Seed the random number generator (if not already seeded)
		srand(); // You can use a specific seed value if needed

		// Generate a random number with a specific length (e.g., 4 digits)
		$randomNumbers = str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);

		// Create the registration number by concatenating the parts
		$registrationNumber = "NBPZ/{$year}/{$randomNumbers}";

		return $registrationNumber;
	}

	$fname = $dbc->real_escape_string($_POST['fname']);
	$lname = $dbc->real_escape_string($_POST['lname']);
	$username = $dbc->real_escape_string($_POST['username']);
	$email = $dbc->real_escape_string($_POST['email']);
	$level = $dbc->real_escape_string($_POST['level']);
	$depart = $dbc->real_escape_string($_POST['department']);
	$password = $dbc->real_escape_string($_POST['password']);
	$studentRegNumber = generateStudentRegistrationNumber();

	// File upload handling
	$targetDirectory = "admin/uploads/"; // Change this to the directory where you want to store the files
	$waecUploadPath = $targetDirectory . basename($_FILES["waec_upload"]["name"]);
	$jambUploadPath = $targetDirectory . basename($_FILES["jamb_upload"]["name"]);

	if (
		move_uploaded_file($_FILES["waec_upload"]["tmp_name"], $waecUploadPath) &&
		move_uploaded_file($_FILES["jamb_upload"]["tmp_name"], $jambUploadPath)
	) {
		// File uploads successful
		$sql = "INSERT INTO student (std_reg, fname, lname, username, email, password, level, department, waec_upload, jamb_upload, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')";
		$stmt = $dbc->prepare($sql);

		if ($stmt) {
			$stmt->bind_param("ssssssssss", $studentRegNumber, $fname, $lname, $username, $email, $password, $level, $depart, $waecUploadPath, $jambUploadPath);

			if ($stmt->execute()) {
				$successMessage = "Your application has been submitted successfully. It is under review.";
			} else {
				$errorMessage = "Error: " . $stmt->error;
			}

			$stmt->close();
		} else {
			$errorMessage = "Error: " . $dbc->error;
		}
	} else {
		$errorMessage = "Error uploading files.";
	}
}
?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<title>Nubapoly CS E-Learning System - Student Login/Register</title>
	<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="assets/css/login_register.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

</head>

<body>
	<div class="container">

		<div class="col-lg-6 mx-auto">
			<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
			<h1>Nubapoly CS E-Learning System</h1>
			<div id="register-form" class="register-form">
			<?php
                if (isset($successMessage)) {
                    echo '<div class="alert alert-success">' . $successMessage . '</div>';
                } elseif (isset($errorMessage)) {
                    echo '<div class="alert alert-danger">' . $errorMessage . '</div>';
                }
                ?>
			<form method="post" enctype="multipart/form-data">
					<input type="hidden" name="action" value="register">
					<input type="text" name="fname" placeholder="First Name">
					<input type="text" name="lname" placeholder="Last Name">
					<input type="text" name="email" placeholder="Email">
					<input type="text" name="username" placeholder="Username">

					<select id="department-filter" name="department" class="form-select form-select-sm mb-3" aria-label=".form-select-sm">

						<option value="">Department</option>
						<option value="Information Technology">Information Technology</option>
						<option value="Cyber Security">Cyber Security</option>
						<option value="Software Engineering">Software Engineering</option>
						<option value="Artificial Intelligence ">Artificial Intelligence </option>

					</select>

					<select id="department-filter" name="level" class="form-select form-select-sm mb-3" aria-label=".form-select-sm">

						<option value="">Level</option>
						<option value="ND I">ND I</option>
						<option value="ND II">ND II</option>
						<option value="HND I">HND I</option>
						<option value="HND II">HND II</option>

					</select>
					<label for="Waec">Waec</label>
					<input type="file" name="waec_upload" accept=".pdf, .doc, .docx, .jpg, .png, .jpeg">
                    <label for="Jamb">Jamb
					<input type="file" name="jamb_upload" accept=".pdf, .doc, .docx, .jpg, .png, .jpeg">
					<input type="password" name="password" placeholder="Password">
					<button type="submit">Register</button>
				</form>
				<div class="form-toggle">
					Already have an account? <a href="login.php">Login here</a>
				</div>
				<div class="form-toggle">
					Go back to Home Page <a href="index.php">Home Page</a>
				</div>
			</div>
		</div>
</body>

</html>