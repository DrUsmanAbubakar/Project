<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Viewer</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ywMpvEz1GQw5L/1BJD0aMy8Yz3xH+oP9DP1yrV1hZL8S45/PfBDifjBRSGuP1BKKQ" crossorigin="anonymous">
</head>
<body class="bg-light d-flex align-items-center justify-content-center" style="height: 100vh;">

<?php
// Ensure the file parameter is provided
if (isset($_GET['file'])) {
    $file = $_GET['file'];

    // Ensure the file exists
    if (file_exists($file)) {
        // Set appropriate headers for file type
        header('Content-Type: ' . mime_content_type($file));
        header('Content-Disposition: inline; filename="' . basename($file) . '"');

        // Output the file content
        readfile($file);
        exit;
    } else {
        // File not found warning
        echo '<div class="alert alert-warning text-center" role="alert">
                File not found.
                <br>
                <a href="javascript:history.back()" class="btn btn-primary mt-3">Go Back</a>
            </div>';
    }
} else {
    // Invalid file request warning
    echo '<div class="alert alert-warning text-center" role="alert">
            Invalid file request.
            <br>
            <a href="javascript:history.back()" class="btn btn-primary mt-3">Go Back</a>
        </div>';
}
?>

<!-- Bootstrap JS and Popper.js for Bootstrap components -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-dpETFE83A5RkpWzpX53I70vdhGG93iC2MLAhU5XY6x4NlR1QFXYu8fgDO6dA6L3h" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js" integrity="sha384-JZfYwe1byqDzL/yw1wcWN5VKtGYjAkDDdjxqCNnFy1ZI82jW8jUb5M1v16i9zlnN" crossorigin="anonymous"></script>
</body>
</html>
