<?php

session_start();

include_once 'connection.php';


if ( isset($_SESSION['loggedInAdmin']) ) {
	header('location: ./admin/dashboard.php');exit;
}
	
if ( isset($_POST['action']) AND $_POST['action'] === 'login' ) {

	$username = $dbc->real_escape_string( $_POST['username'] );
	$password = $dbc->real_escape_string( $_POST['password'] );

	$sql = "SELECT `id`,`username`,`password`
	FROM `admin`
	WHERE `username`='$username' AND `password`='$password'";

	$query = $dbc->query( $sql );

	if ( $dbc->affected_rows > 0 ){
		session_start();
		$id = $query->fetch_assoc()['id'];
		$_SESSION['loggedInAdmin']['id'] = $id;
		$_SESSION['loggedInAdmin']['username'] = $username;
		header('location: ./admin/dashboard.php');exit;
	}
	else{
		$msg = "Incorrect username or password!";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Nubapoly CS E-Learning System - Admin Login</title>
	<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="assets/css/login_register.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href=css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="js/bootstrap.min.js">
</head>
<body>
	<div class="container col-lg-4">
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">
		<h1>Admin Login</h1>
		<?php
		if (isset($msg))
		echo '<div class="alert alert-danger" role="alert">' .$msg.'</div>';
		?>

		<form id="adminLoginForm" method="post">
			<input type="hidden" name="action" value="login">
			<label for="username">Username:</label>
			<input type="text" id="username" name="username" placeholder="Enter your username" required>
			<label for="password">Password:</label>
			<input type="password" id="password" name="password" placeholder="Enter your password" required>
			<button type="submit">Login</button>
		</form>
		<div class="form-toggle">
				Go back to Home Page <a href="index.php">Home Page</a>
	</div>
</body>
</html>