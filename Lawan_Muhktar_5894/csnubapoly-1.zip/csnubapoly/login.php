<?php
session_start();

include_once 'connection.php';

if (isset($_SESSION['loggedInUser'])) {
    header('location: ./student/dashboard.php');
    exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'login') {

    $username = $dbc->real_escape_string($_POST['username']);
    $password = $dbc->real_escape_string($_POST['password']);

    $sql = "SELECT `id`,`username`,`password`, `status`
            FROM `student`
            WHERE `username`='$username' AND `password`='$password'";

    $query = $dbc->query($sql);

    if ($dbc->affected_rows > 0) {
        $student = $query->fetch_assoc();
        $id = $student['id'];
        $status = $student['status'];

        if ($status === 'approved') {
            $_SESSION['student_id'] = $id;
            $_SESSION['loggedInUser']['username'] = $username;
            $_SESSION['loggedInUser']['password'] = $password;

            header('location: ./student/dashboard.php');
            exit;
        } else {
		   $msg = '<div class="alert alert-warning">Your account is not approved. Status <i>'.$status.'</i></div>';
        }
    } else {
       // $msg = "Incorrect username or password!";
		$msg = '<div class="alert alert-danger">Incorrect username or password!</div>';

    }
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Nubapoly CS E-Learning System - Admin Login</title>
	<link rel="stylesheet" type="text/css" href="assets/css/styles.css">
	<link rel="stylesheet" type="text/css" href="assets/css/login_register.css">
	<link rel="stylesheet" type="text/css" href="/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="/js/bootstrap.js">
	<link rel="stylesheet" type="text/css" href="/js/bootstrap.min.js">
</head>
<body>
	<div class="container col-lg-4 mx-auto">
		<img src="polylogo.png" alt="Image" style="display: block; margin: 0 auto;">

		<h1>Nubapoly CS E-Learning System</h1>
		<?php
            if (isset($msg)) {
                echo $msg;
            }
            ?>
		<div id="login-form" class="login-form">
	
			<form method="post">
			<input type="hidden" name="action" value="login">
				<input type="text" name="username" placeholder="Username">
				<input type="password" name="password" placeholder="Password">
				<button type="submit">Login</button>
			</form>
			<div class="form-toggle">
				Don't have an account? <a href="register.php">Register here</a>
				<div class="form-toggle">
				Go back to Home Page <a href="index.php">Home Page</a>
			</div>
		</div>
	</div>
</body>
</html>